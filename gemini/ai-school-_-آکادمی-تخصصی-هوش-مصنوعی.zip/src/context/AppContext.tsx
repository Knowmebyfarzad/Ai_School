import React, { createContext, useContext, useState, useEffect } from 'react';
import { Course, Currency, Language, Order, User } from '../types';
import { INITIAL_COURSES, INITIAL_ORDERS, INITIAL_USER } from '../data/seedData';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  currency: Currency;
  setCurrency: (curr: Currency) => void;
  currentView: 'catalog' | 'library' | 'admin' | 'classroom';
  setCurrentView: (view: 'catalog' | 'library' | 'admin' | 'classroom') => void;

  courses: Course[];
  orders: Order[];
  currentUser: User;

  // Active modals and detail views
  selectedCourseForDetails: Course | null;
  setSelectedCourseForDetails: (c: Course | null) => void;
  selectedCourseForCheckout: Course | null;
  setSelectedCourseForCheckout: (c: Course | null) => void;
  selectedOrderForInvoice: Order | null;
  setSelectedOrderForInvoice: (o: Order | null) => void;

  // Active video classroom playback
  activeCourse: Course | null;
  activeChapterId: string | null;
  setActiveChapterId: (id: string | null) => void;
  openClassroom: (courseId: string, chapterId?: string) => void;

  // Actions
  enrollInCourse: (course: Course, gateway: 'zarinpal' | 'stripe', discountApplied: number, couponCode?: string, cardMask?: string) => Order;
  updateWatchProgress: (courseId: string, chapterId: string, seconds: number, markCompleted?: boolean) => void;
  createCourse: (newCourse: Course) => void;
  updateCourse: (course: Course) => void;
  deleteCourse: (courseId: string) => void;
  grantCourseAccess: (userId: string, courseId: string) => void;
  revokeCourseAccess: (userId: string, courseId: string) => void;
  resetAllData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  LANG: 'aischool_lang_v1',
  CURR: 'aischool_curr_v1',
  COURSES: 'aischool_courses_v1',
  ORDERS: 'aischool_orders_v1',
  USER: 'aischool_user_v1',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LANG);
    return (saved === 'en' || saved === 'fa') ? saved : 'fa';
  });

  const [currency, setCurrencyState] = useState<Currency>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CURR);
    return (saved === 'USD' || saved === 'IRR') ? saved : 'IRR';
  });

  const [currentView, setCurrentView] = useState<'catalog' | 'library' | 'admin' | 'classroom'>('catalog');

  const [courses, setCourses] = useState<Course[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.COURSES);
      return saved ? JSON.parse(saved) : INITIAL_COURSES;
    } catch {
      return INITIAL_COURSES;
    }
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ORDERS);
      return saved ? JSON.parse(saved) : INITIAL_ORDERS;
    } catch {
      return INITIAL_ORDERS;
    }
  });

  const [currentUser, setCurrentUser] = useState<User>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.USER);
      return saved ? JSON.parse(saved) : INITIAL_USER;
    } catch {
      return INITIAL_USER;
    }
  });

  const [selectedCourseForDetails, setSelectedCourseForDetails] = useState<Course | null>(null);
  const [selectedCourseForCheckout, setSelectedCourseForCheckout] = useState<Course | null>(null);
  const [selectedOrderForInvoice, setSelectedOrderForInvoice] = useState<Order | null>(null);

  const [activeCourseId, setActiveCourseId] = useState<string | null>(null);
  const [activeChapterId, setActiveChapterId] = useState<string | null>(null);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LANG, language);
    document.documentElement.dir = language === 'fa' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CURR, currency);
  }, [currency]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(courses));
  }, [courses]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
  }, [currentUser]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const setCurrency = (curr: Currency) => {
    setCurrencyState(curr);
  };

  const activeCourse = courses.find(c => c.id === activeCourseId) || null;

  const openClassroom = (courseId: string, chapterId?: string) => {
    const course = courses.find(c => c.id === courseId);
    if (!course) return;

    setActiveCourseId(courseId);
    if (chapterId) {
      setActiveChapterId(chapterId);
    } else {
      const progress = currentUser.watchProgress[courseId];
      setActiveChapterId(progress?.lastChapterId || course.chapters[0]?.id || null);
    }
    setCurrentView('classroom');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const enrollInCourse = (
    course: Course,
    gateway: 'zarinpal' | 'stripe',
    discountApplied: number,
    couponCode?: string,
    cardMask?: string
  ): Order => {
    const price = currency === 'IRR' ? course.priceIRR : course.priceUSD;
    const subtotal = price;
    const discount = discountApplied;
    const tax = currency === 'USD' ? +(subtotal * 0.05).toFixed(2) : 0; // 5% digital services tax for USD
    const total = Math.max(0, subtotal - discount + tax);

    const now = new Date().toISOString();
    const orderId = `ord-${Math.floor(1000 + Math.random() * 9000)}`;
    const txRef = gateway === 'zarinpal' 
      ? `ZRN-${Math.floor(10000000 + Math.random() * 90000000)}` 
      : `pi_${Math.random().toString(36).substring(2, 14)}`;
    const trkCode = gateway === 'zarinpal'
      ? `TRK-IR-${Math.floor(100000 + Math.random() * 900000)}`
      : `STR-US-${Math.floor(100000 + Math.random() * 900000)}`;

    const newOrder: Order = {
      id: orderId,
      userId: currentUser.id,
      userEmail: currentUser.email,
      userName: currentUser.name,
      items: [
        {
          courseId: course.id,
          title: course.title,
          priceIRR: course.priceIRR,
          priceUSD: course.priceUSD
        }
      ],
      currency,
      subtotal,
      discount,
      couponCode,
      tax,
      total,
      gateway,
      status: 'completed',
      createdAt: now,
      transactionRef: txRef,
      trackingCode: trkCode,
      cardMask: cardMask || (gateway === 'zarinpal' ? '۶۰۳۷-۹۹**-****-۲۸۴۱' : '4242-****-****-4242'),
      billingCountry: gateway === 'zarinpal' ? 'Iran' : 'United States'
    };

    // Determine course IDs to grant
    const coursesToGrant = [course.id];
    if (course.isBundle && course.includedCourseIds) {
      coursesToGrant.push(...course.includedCourseIds);
    }

    // Update user enrollments
    setCurrentUser(prev => {
      const existing = new Set(prev.enrolledCourseIds);
      coursesToGrant.forEach(id => existing.add(id));

      const updatedProgress = { ...prev.watchProgress };
      coursesToGrant.forEach(id => {
        if (!updatedProgress[id]) {
          const targetCourse = courses.find(c => c.id === id);
          updatedProgress[id] = {
            lastChapterId: targetCourse?.chapters[0]?.id || '',
            lastPositionSeconds: 0,
            completedChapterIds: [],
            lastWatchedAt: now,
            certificateIssued: false
          };
        }
      });

      return {
        ...prev,
        enrolledCourseIds: Array.from(existing),
        watchProgress: updatedProgress
      };
    });

    // Update course enrollments
    setCourses(prev =>
      prev.map(c => {
        if (coursesToGrant.includes(c.id) && !c.enrolledUserIds.includes(currentUser.id)) {
          return {
            ...c,
            enrolledUserIds: [...c.enrolledUserIds, currentUser.id]
          };
        }
        return c;
      })
    );

    // Append to orders
    setOrders(prev => [newOrder, ...prev]);

    return newOrder;
  };

  const updateWatchProgress = (
    courseId: string,
    chapterId: string,
    seconds: number,
    markCompleted?: boolean
  ) => {
    setCurrentUser(prev => {
      const current = prev.watchProgress[courseId] || {
        lastChapterId: chapterId,
        lastPositionSeconds: 0,
        completedChapterIds: [],
        lastWatchedAt: new Date().toISOString(),
        certificateIssued: false
      };

      const completed = new Set(current.completedChapterIds);
      if (markCompleted) {
        completed.add(chapterId);
      }

      const course = courses.find(c => c.id === courseId);
      const allDone = course && course.chapters.length > 0 && course.chapters.every(ch => completed.has(ch.id));

      return {
        ...prev,
        watchProgress: {
          ...prev.watchProgress,
          [courseId]: {
            ...current,
            lastChapterId: chapterId,
            lastPositionSeconds: Math.floor(seconds),
            completedChapterIds: Array.from(completed),
            lastWatchedAt: new Date().toISOString(),
            certificateIssued: allDone || current.certificateIssued
          }
        }
      };
    });
  };

  const createCourse = (newCourse: Course) => {
    setCourses(prev => [newCourse, ...prev]);
  };

  const updateCourse = (updated: Course) => {
    setCourses(prev => prev.map(c => c.id === updated.id ? updated : c));
  };

  const deleteCourse = (courseId: string) => {
    setCourses(prev => prev.filter(c => c.id !== courseId));
  };

  const grantCourseAccess = (userId: string, courseId: string) => {
    if (userId === currentUser.id) {
      setCurrentUser(prev => ({
        ...prev,
        enrolledCourseIds: Array.from(new Set([...prev.enrolledCourseIds, courseId])),
        watchProgress: {
          ...prev.watchProgress,
          [courseId]: prev.watchProgress[courseId] || {
            lastChapterId: courses.find(c => c.id === courseId)?.chapters[0]?.id || '',
            lastPositionSeconds: 0,
            completedChapterIds: [],
            lastWatchedAt: new Date().toISOString(),
            certificateIssued: false
          }
        }
      }));
    }
    setCourses(prev =>
      prev.map(c => c.id === courseId && !c.enrolledUserIds.includes(userId)
        ? { ...c, enrolledUserIds: [...c.enrolledUserIds, userId] }
        : c
      )
    );
  };

  const revokeCourseAccess = (userId: string, courseId: string) => {
    if (userId === currentUser.id) {
      setCurrentUser(prev => ({
        ...prev,
        enrolledCourseIds: prev.enrolledCourseIds.filter(id => id !== courseId)
      }));
    }
    setCourses(prev =>
      prev.map(c => c.id === courseId
        ? { ...c, enrolledUserIds: c.enrolledUserIds.filter(id => id !== userId) }
        : c
      )
    );
  };

  const resetAllData = () => {
    localStorage.removeItem(STORAGE_KEYS.COURSES);
    localStorage.removeItem(STORAGE_KEYS.ORDERS);
    localStorage.removeItem(STORAGE_KEYS.USER);
    setCourses(INITIAL_COURSES);
    setOrders(INITIAL_ORDERS);
    setCurrentUser(INITIAL_USER);
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        currency,
        setCurrency,
        currentView,
        setCurrentView,
        courses,
        orders,
        currentUser,
        selectedCourseForDetails,
        setSelectedCourseForDetails,
        selectedCourseForCheckout,
        setSelectedCourseForCheckout,
        selectedOrderForInvoice,
        setSelectedOrderForInvoice,
        activeCourse,
        activeChapterId,
        setActiveChapterId,
        openClassroom,
        enrollInCourse,
        updateWatchProgress,
        createCourse,
        updateCourse,
        deleteCourse,
        grantCourseAccess,
        revokeCourseAccess,
        resetAllData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return ctx;
};
