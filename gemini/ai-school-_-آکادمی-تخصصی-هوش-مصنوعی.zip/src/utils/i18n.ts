import { Currency, Language, LocalizedString } from '../types';

export const toPersianDigits = (num: number | string): string => {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(num).replace(/[0-9]/g, (w) => persianDigits[+w]);
};

export const formatPrice = (amount: number, currency: Currency, lang: Language): string => {
  if (currency === 'IRR') {
    const formatted = amount.toLocaleString('en-US');
    if (lang === 'fa') {
      return `${toPersianDigits(formatted)} تومان`;
    }
    return `${formatted} Tomans`;
  } else {
    const formatted = amount.toLocaleString('en-US', {
      minimumFractionDigits: amount % 1 === 0 ? 0 : 2,
      maximumFractionDigits: 2
    });
    if (lang === 'fa') {
      return `${toPersianDigits(formatted)} دلار`;
    }
    return `$${formatted}`;
  }
};

export const formatDuration = (totalSeconds: number, lang: Language): string => {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);

  if (lang === 'fa') {
    if (hours > 0 && minutes > 0) {
      return `${toPersianDigits(hours)} ساعت و ${toPersianDigits(minutes)} دقیقه`;
    }
    if (hours > 0) {
      return `${toPersianDigits(hours)} ساعت`;
    }
    return `${toPersianDigits(minutes)} دقیقه`;
  } else {
    if (hours > 0 && minutes > 0) {
      return `${hours}h ${minutes}m`;
    }
    if (hours > 0) {
      return `${hours} hrs`;
    }
    return `${minutes} mins`;
  }
};

export const formatPlaybackTime = (seconds: number): string => {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

export const UI_TEXT = {
  brandName: { fa: 'آکادمی هوش مصنوعی', en: 'AI School' },
  brandTagline: { fa: 'مسترکلاس‌های تخصصی هوش مصنوعی', en: 'Executive AI Masterclasses' },
  navCourses: { fa: 'دوره‌های آموزشی', en: 'Masterclasses' },
  navPackages: { fa: 'پکیج‌های دیجیتال', en: 'Digital Bundles' },
  navLibrary: { fa: 'کتابخانه من', en: 'My Library' },
  navAdmin: { fa: 'پنل مدیریت', en: 'Admin Console' },
  navLearnerView: { fa: 'نمای کاربر', en: 'Learner View' },

  filterAll: { fa: 'همه آموزش‌ها', en: 'All Tracks' },
  filterLLM: { fa: 'مدل‌های زبانی و عامل‌ها', en: 'LLMs & Agents' },
  filterVision: { fa: 'بینایی و دیفیوژن', en: 'Vision & Diffusion' },
  filterSystems: { fa: 'زیرساخت و پایگاه‌های برداری', en: 'Infrastructure & Systems' },
  filterBundles: { fa: 'پکیج‌های جامع', en: 'Full Bundles' },

  heroTitle: {
    fa: 'تسلط عمیق بر مهندسی هوش مصنوعی مدرن در مسترکلاس‌های فشرده ۳ ساعته',
    en: 'Master Modern AI Engineering in High-Density 3-Hour Masterclasses'
  },
  heroSubtitle: {
    fa: 'محتوای پیشرفته ویدئویی بدون اتلاف وقت، کدهای سورس عملیاتی، پلیر استریم امن و دسترسی همیشگی با پرداخت یکباره.',
    en: 'Zero-filler executive curriculum, production repositories, hardened dynamic player, and lifetime access with one-time purchase.'
  },
  heroBadge: { fa: 'کیفیت تضمین‌شده سازمانی', en: 'Enterprise Grade Curriculum' },
  heroCtaBrowse: { fa: 'مشاهده دوره‌ها', en: 'Explore Masterclasses' },
  heroCtaBundle: { fa: 'پکیج طلایی با ۴۰٪ تخفیف', en: 'Mastery Bundle (40% Off)' },

  statsRuntimes: { fa: 'ساعت آموزش ویدیویی عمیق', en: 'Hours of Deep Video Content' },
  statsStudents: { fa: 'دانشجوی تخصصی فعال', en: 'Active Technical Learners' },
  statsGuarantee: { fa: 'مالکیت همیشگی بدون اشتراک', en: 'Perpetual Access, Zero Subscriptions' },
  statsSecurity: { fa: 'استریم امن با واترمارک پویا', en: 'Dynamic Watermarked Stream' },

  enrollNow: { fa: 'خرید و ثبت‌نام در دوره', en: 'Enroll Now' },
  continueLearning: { fa: 'ادامه یادگیری', en: 'Continue Learning' },
  viewSyllabus: { fa: 'مشاهده سرفصل‌ها', en: 'View Syllabus' },
  enrolled: { fa: 'ثبت‌نام شده', en: 'Enrolled' },
  includedInBundle: { fa: 'موجود در پکیج طلایی', en: 'Included in Gold Bundle' },
  modulesCount: { fa: 'فصل آموزشی', en: 'Modules' },

  // Course Details
  syllabusTitle: { fa: 'سرفصل‌های آموزشی دوره (۳ ساعت)', en: 'Course Syllabus Breakdown (~3 Hours)' },
  learningObjectives: { fa: 'آنچه در این مسترکلاس می‌آموزید', en: 'Core Learning Objectives' },
  prerequisites: { fa: 'پیش‌نیازها و ملزومات', en: 'Prerequisites' },
  instructorDossier: { fa: 'درباره مدرس', en: 'Instructor Dossier' },
  experienceYears: { fa: 'سال سابقه تحقیق و استقرار صنعتی', en: 'years of enterprise engineering' },
  previewVideo: { fa: 'ویدئوی معرفی دوره', en: 'Course Teaser & Overview' },

  // Checkout
  checkoutTitle: { fa: 'تکمیل سفارش و پرداخت ایمن', en: 'Secure Checkout' },
  selectGateway: { fa: 'انتخاب درگاه پرداخت', en: 'Select Payment Gateway' },
  gatewayZarinpal: { fa: 'درگاه بانکی شتاب / زرین‌پال (تومان)', en: 'Iranian Gateway (Shaparak / Tomans)' },
  gatewayStripe: { fa: 'درگاه بین‌المللی استریپ / دلاری‌شو (دلار)', en: 'International Card (Stripe / USD)' },
  orderSummary: { fa: 'خلاصه فاکتور', en: 'Order Summary' },
  subtotal: { fa: 'مبلغ کل', en: 'Subtotal' },
  discount: { fa: 'تخفیف', en: 'Discount' },
  tax: { fa: 'مالیات و عوارض', en: 'Tax & Compliance' },
  finalTotal: { fa: 'مبلغ قابل پرداخت', en: 'Total Amount' },
  couponPrompt: { fa: 'کد تخفیف دارید؟ (AISCHOOL20 برای ۲۰٪ تخفیف)', en: 'Have a coupon? (Use AISCHOOL20 for 20% off)' },
  applyCoupon: { fa: 'اعمال کد', en: 'Apply' },
  payButton: { fa: 'پرداخت و دریافت آنی دسترسی', en: 'Pay & Grant Instant Access' },
  secureNotice: {
    fa: 'اطلاعات پرداخت در بستر رمزنگاری‌شده پردازش شده و روی سرور ذخیره نمی‌شود.',
    en: 'Card data is encrypted and processed via gateway tokenization. Never stored on server.'
  },

  // Player
  playerSecurityNotice: {
    fa: 'این استریم با واترمارک پویا محافظت شده و به شناسه شما متصل است.',
    en: 'This stream is protected with dynamic forensic watermarks tied to your identity.'
  },
  drmTokenHealth: { fa: 'وضعیت توکن استریم: معتبر (انقضا در ۱۵ دقیقه)', en: 'Stream Token Status: Valid (Rotating in 15m)' },
  speed: { fa: 'سرعت پخش', en: 'Speed' },
  chaptersList: { fa: 'فهرست فصل‌های ویدیو', en: 'Video Chapters' },
  markComplete: { fa: 'علامت‌گذاری به عنوان پایان یافته', en: 'Mark Chapter as Completed' },
  completed: { fa: 'تکمیل شده', en: 'Completed' },
  downloadResources: { fa: 'پیوست‌ها و کدهای تمرینی', en: 'Source Code & Attachments' },
  drmArchitectureInfo: { fa: 'مشاهده مشخصات امنیتی و DRM', en: 'View DRM & Security Spec' },

  // Library
  myLibraryTitle: { fa: 'کتابخانه یادگیری من', en: 'My Learning Library' },
  myLibrarySubtitle: {
    fa: 'دوره‌های خریداری شده شما با دسترسی نامحدود همیشگی و ذخیره پیشرفت تماشا.',
    en: 'Your enrolled masterclasses with perpetual access and automatic progress sync.'
  },
  progress: { fa: 'پیشرفت مشاهده', en: 'Progress' },
  certificateAvailable: { fa: 'مدرک پایان دوره آماده است', en: 'Certificate Ready' },
  downloadCertificate: { fa: 'مشاهده گواهی پایان دوره', en: 'View Certificate' },
  emptyLibrary: { fa: 'هنوز در دوره‌ای ثبت‌نام نکرده‌اید.', en: 'You have not enrolled in any masterclasses yet.' },
  emptyLibraryCta: { fa: 'مشاهده کاتالوگ دوره‌ها', en: 'Browse Masterclasses' },

  // Admin
  adminTitle: { fa: 'پنل مدیریت آکادمی هوش مصنوعی', en: 'AI School Administration Console' },
  adminSubtitle: { fa: 'مدیریت دوره‌ها، پکیج‌های دیجیتال، سفارش‌ها، کاربران و مانیتورینگ استریم', en: 'Manage courses, digital bundles, order ledgers, learners and DRM sessions' },
  tabCourses: { fa: 'دوره‌ها و پکیج‌ها', en: 'Courses & Bundles' },
  tabOrders: { fa: 'سفارش‌ها و مالی', en: 'Orders & Accounting' },
  tabUsers: { fa: 'کاربران و دسترسی‌ها', en: 'Users & Access' },
  tabSecurity: { fa: 'مانیتورینگ استریم و DRM', en: 'Stream & DRM Monitor' },

  totalRevenueIRR: { fa: 'مجموع درآمد ریالی', en: 'Total IRR Revenue' },
  totalRevenueUSD: { fa: 'مجموع درآمد دلاری', en: 'Total USD Revenue' },
  activeLearners: { fa: 'دانشجویان فعال', en: 'Active Learners' },
  totalStreamHours: { fa: 'ساعات استریم پخش‌شده', en: 'Stream Hours Delivered' },

  newCourseBtn: { fa: '+ ایجاد دوره جدید', en: '+ New Course' },
  editCourse: { fa: 'ویرایش دوره', en: 'Edit Course' },
  deleteCourse: { fa: 'حذف', en: 'Delete' },
  grantAccess: { fa: 'اعطای دسترسی مستقیم', en: 'Grant Access' },
  revokeAccess: { fa: 'لغو دسترسی', en: 'Revoke Access' },
  viewInvoice: { fa: 'مشاهده فاکتور رسمی', en: 'View Invoice' }
};

export const getStr = (obj: LocalizedString, lang: Language): string => {
  return obj[lang] || obj['en'] || '';
};
