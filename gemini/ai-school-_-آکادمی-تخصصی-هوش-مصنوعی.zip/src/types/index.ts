export type Language = 'fa' | 'en';
export type Currency = 'IRR' | 'USD';

export interface LocalizedString {
  fa: string;
  en: string;
}

export interface ChapterResource {
  id: string;
  title: LocalizedString;
  fileType: 'pdf' | 'zip' | 'ipynb' | 'json';
  fileSize: string;
  downloadUrl?: string;
}

export interface Chapter {
  id: string;
  title: LocalizedString;
  durationSeconds: number; // Duration of chapter in seconds
  videoUrl: string; // Protected stream source
  summary: LocalizedString;
  keyPoints: LocalizedString[];
  resources: ChapterResource[];
}

export interface Instructor {
  id: string;
  name: LocalizedString;
  title: LocalizedString;
  bio: LocalizedString;
  avatar: string;
  experienceYears: number;
}

export interface Course {
  id: string;
  slug: string;
  title: LocalizedString;
  subtitle: LocalizedString;
  description: LocalizedString;
  category: 'llm' | 'vision' | 'agents' | 'systems' | 'bundle';
  level: 'beginner' | 'intermediate' | 'advanced' | 'all-levels';
  thumbnail: string;
  previewVideoUrl: string;
  instructor: Instructor;
  totalDurationSeconds: number; // Total course duration (~10,800s = 3 hours)
  priceIRR: number; // in Tomans
  originalPriceIRR: number;
  priceUSD: number; // in USD
  originalPriceUSD: number;
  chapters: Chapter[];
  isBundle?: boolean;
  includedCourseIds?: string[];
  enrolledUserIds: string[];
  rating: number;
  reviewsCount: number;
  updatedAt: string;
  learningOutcomes: LocalizedString[];
  prerequisites: LocalizedString[];
}

export interface OrderItem {
  courseId: string;
  title: LocalizedString;
  priceIRR: number;
  priceUSD: number;
}

export interface Order {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  userPhone?: string;
  items: OrderItem[];
  currency: Currency;
  subtotal: number;
  discount: number;
  couponCode?: string;
  tax: number;
  total: number;
  gateway: 'zarinpal' | 'stripe';
  status: 'completed' | 'pending' | 'failed' | 'refunded';
  createdAt: string;
  transactionRef: string;
  trackingCode: string;
  cardMask: string;
  billingCountry: string;
}

export interface WatchProgress {
  lastChapterId: string;
  lastPositionSeconds: number;
  completedChapterIds: string[];
  lastWatchedAt: string;
  certificateIssued: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'learner' | 'admin';
  avatar: string;
  enrolledCourseIds: string[];
  watchProgress: Record<string, WatchProgress>;
}

export interface StreamToken {
  token: string;
  courseId: string;
  chapterId: string;
  userId: string;
  userEmail: string;
  issuedAt: number;
  expiresAt: number;
  clientIpHash: string;
  active: boolean;
}
