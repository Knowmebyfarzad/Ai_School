import React from 'react';
import { useApp } from '../../context/AppContext';
import { formatPrice, toPersianDigits, UI_TEXT } from '../../utils/i18n';
import { X, Printer, ShieldCheck, CheckCircle2, Download, Building } from 'lucide-react';

export const InvoiceModal: React.FC = () => {
  const { 
    language, 
    selectedOrderForInvoice: order, 
    setSelectedOrderForInvoice 
  } = useApp();

  if (!order) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-950/85 backdrop-blur-md">
      <div 
        className="relative w-full max-w-2xl rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Top Control Bar (Hidden on print) */}
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4 bg-slate-950/60 print:hidden">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
            <span>رسید رسمی و فاکتور فروش دیجیتال</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-700 transition-colors"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>چاپ فاکتور</span>
            </button>

            <button
              onClick={() => setSelectedOrderForInvoice(null)}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Sheet */}
        <div className="p-6 sm:p-8 space-y-6 bg-slate-900 text-slate-200 text-xs font-sans">
          
          {/* Header Row */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
            <div>
              <h2 className="text-xl font-black text-white">
                {UI_TEXT.brandName[language]}
              </h2>
              <p className="text-slate-400 text-xs mt-1">
                آکادمی آموزش‌های تخصصی هوش مصنوعی و مسترکلاس‌های دیجیتال
              </p>
              <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                شناسه ملی: ۱۴۰۰۸۹۲۳۰۱۱ · پشتیبانی: support@aischool.ir
              </p>
            </div>

            <div className="text-left sm:text-right font-mono space-y-1">
              <div className="text-sm font-bold text-cyan-400">
                فاکتور شماره: {order.id.toUpperCase()}
              </div>
              <div className="text-slate-400 text-[11px]">
                تاریخ صدور: {new Date(order.createdAt).toLocaleDateString('fa-IR')}
              </div>
              <div className="inline-flex items-center gap-1 text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded text-[10px] font-sans font-semibold">
                <CheckCircle2 className="h-3 w-3" />
                <span>پرداخت موفق (تسویه شده)</span>
              </div>
            </div>
          </div>

          {/* Customer & Gateway Info Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 rounded-xl border border-slate-800/80 bg-slate-950/40 p-4">
            <div className="space-y-1">
              <span className="text-slate-500 text-[11px] block">اطلاعات خریدار:</span>
              <div className="font-semibold text-white">{order.userName}</div>
              <div className="font-mono text-slate-400">{order.userEmail}</div>
              <div className="text-slate-400">موقعیت جغرافیایی: {order.billingCountry}</div>
            </div>

            <div className="space-y-1 sm:text-left font-mono">
              <span className="text-slate-500 text-[11px] block font-sans sm:text-left">مشخصات تراکنش:</span>
              <div className="text-slate-300">درگاه: <span className="uppercase font-bold text-white">{order.gateway}</span></div>
              <div className="text-slate-400">کارت: {order.cardMask}</div>
              <div className="text-cyan-400 truncate">کد رهگیری: {order.trackingCode}</div>
              <div className="text-[11px] text-slate-500">مرجع: {order.transactionRef}</div>
            </div>
          </div>

          {/* Line Items Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-[11px] text-slate-400 font-semibold">
                  <th className="py-2.5 px-3">ردیف</th>
                  <th className="py-2.5 px-3">شرح خدمت / دوره آموزشی</th>
                  <th className="py-2.5 px-3 text-center">نوع دسترسی</th>
                  <th className="py-2.5 px-3 text-left">مبلغ واحد</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
                {order.items.map((item, idx) => (
                  <tr key={item.courseId}>
                    <td className="py-3 px-3 text-slate-400">{idx + 1}</td>
                    <td className="py-3 px-3 font-sans font-medium text-white">
                      {item.title[language]}
                    </td>
                    <td className="py-3 px-3 text-center font-sans text-slate-400 text-[11px]">
                      مادام‌العمر (یکباره)
                    </td>
                    <td className="py-3 px-3 text-left text-slate-200">
                      {formatPrice(order.subtotal, order.currency, language)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Total Calculation Strip */}
          <div className="border-t border-slate-800 pt-4 flex justify-end">
            <div className="w-full sm:w-64 space-y-2 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>جمع کل سفارش:</span>
                <span className="font-mono">{formatPrice(order.subtotal, order.currency, language)}</span>
              </div>

              {order.discount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>تخفیف ({order.couponCode || 'کوپن'}):</span>
                  <span className="font-mono">- {formatPrice(order.discount, order.currency, language)}</span>
                </div>
              )}

              {order.tax > 0 && (
                <div className="flex justify-between text-slate-400">
                  <span>مالیات بر ارزش افزوده:</span>
                  <span className="font-mono">+{formatPrice(order.tax, order.currency, language)}</span>
                </div>
              )}

              <div className="flex justify-between border-t border-slate-800 pt-2 text-sm font-bold text-white">
                <span>مبلغ پرداخت شده:</span>
                <span className="font-mono text-cyan-400">
                  {formatPrice(order.total, order.currency, language)}
                </span>
              </div>
            </div>
          </div>

          {/* Footer Legal Terms */}
          <div className="border-t border-slate-800/80 pt-4 text-[10px] text-slate-500 leading-relaxed text-center sm:text-right">
            این سند بر اساس قوانین تجارت الکترونیک و استانداردهای انطباق مالیاتی صادر گردیده و به منزله فاکتور رسمی تسویه شده فروشگاه دیجیتال AI School می‌باشد. اطلاعات پرداخت از طریق درگاه شاپرک/استریپ توکنایز شده و هیچ داده‌ای از کارت روی سرور ذخیره نمی‌شود.
          </div>

        </div>

      </div>
    </div>
  );
};
