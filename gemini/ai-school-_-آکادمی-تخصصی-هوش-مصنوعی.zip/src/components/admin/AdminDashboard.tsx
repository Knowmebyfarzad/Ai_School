import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatDuration, formatPrice, toPersianDigits, UI_TEXT } from '../../utils/i18n';
import { Course } from '../../types';
import { 
  BarChart3, 
  Layers, 
  ShoppingCart, 
  Users, 
  ShieldCheck, 
  Plus, 
  Trash2, 
  Edit3, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  RotateCcw,
  Key,
  Lock,
  DollarSign
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { 
    language, 
    currency, 
    courses, 
    orders, 
    currentUser, 
    createCourse, 
    deleteCourse, 
    updateCourse,
    grantCourseAccess,
    revokeCourseAccess,
    setSelectedOrderForInvoice,
    resetAllData
  } = useApp();

  const [activeTab, setActiveTab] = useState<'courses' | 'orders' | 'users' | 'security'>('courses');
  const [showNewCourseModal, setShowNewCourseModal] = useState(false);

  // New course form state
  const [newTitleFa, setNewTitleFa] = useState('');
  const [newTitleEn, setNewTitleEn] = useState('');
  const [newCategory, setNewCategory] = useState<'llm' | 'vision' | 'systems'>('llm');
  const [newPriceIRR, setNewPriceIRR] = useState(2500000);
  const [newPriceUSD, setNewPriceUSD] = useState(39);
  const [newInstructorName, setNewInstructorName] = useState('دکتر پوریا شمس');

  // Revenue computations
  const totalRevenueIRR = orders
    .filter(o => o.currency === 'IRR' && o.status === 'completed')
    .reduce((sum, o) => sum + o.total, 0);

  const totalRevenueUSD = orders
    .filter(o => o.currency === 'USD' && o.status === 'completed')
    .reduce((sum, o) => sum + o.total, 0);

  const allEnrolledUsersCount = new Set(courses.flatMap(c => c.enrolledUserIds)).size;

  const handleCreateCourseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitleFa || !newTitleEn) return;

    const id = `course-${Date.now()}`;
    const newCourseObj: Course = {
      id,
      slug: `custom-${id}`,
      title: { fa: newTitleFa, en: newTitleEn },
      subtitle: {
        fa: 'مسترکلاس پیشرفته ۳ ساعته با پروژه‌های عملیاتی',
        en: 'Advanced 3-hour masterclass with production codebases'
      },
      description: {
        fa: 'بررسی عمیق معماری و پیاده‌سازی کاربردی در محیط‌های صنعتی.',
        en: 'In-depth architectural review and real-world industrial deployment.'
      },
      category: newCategory,
      level: 'intermediate',
      thumbnail: courses[0]?.thumbnail || '/src/assets/images/ai_course_llm_agents_1792412069566.jpg',
      previewVideoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      instructor: {
        id: `inst-${Date.now()}`,
        name: { fa: newInstructorName, en: 'Dr. Pouria Shams' },
        title: { fa: 'متخصص ارشد هوش مصنوعی', en: 'Senior AI Specialist' },
        bio: { fa: 'پژوهشگر و مدرس دوره‌های تخصصی مهندسی یادگیری عمیق.', en: 'Senior deep learning instructor.' },
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=200&q=80',
        experienceYears: 10
      },
      totalDurationSeconds: 10800, // 3 hours
      priceIRR: newPriceIRR,
      originalPriceIRR: Math.round(newPriceIRR * 1.3),
      priceUSD: newPriceUSD,
      originalPriceUSD: Math.round(newPriceUSD * 1.3),
      rating: 5.0,
      reviewsCount: 1,
      updatedAt: '2026-10-19',
      enrolledUserIds: [],
      learningOutcomes: [
        { fa: 'تسلط بر زیرساخت‌ها و ابزارهای صنعتی هوش مصنوعی', en: 'Mastering modern AI industrial toolchains' }
      ],
      prerequisites: [
        { fa: 'پایتون و اصول یادگیری ماشین', en: 'Python and machine learning fundamentals' }
      ],
      chapters: [
        {
          id: `chap-${Date.now()}-1`,
          title: { fa: 'ماژول اول: مبانی و استقرار اولیه', en: 'Module 1: Foundations' },
          durationSeconds: 3600,
          videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
          summary: { fa: 'بررسی مفاهیم اولیه و راه‌اندازی محیط', en: 'Core concepts and environment setup' },
          keyPoints: [{ fa: 'راه‌اندازی محیط', en: 'Environment setup' }],
          resources: [{ id: 'r1', title: { fa: 'کدهای پروژه', en: 'Source Code' }, fileType: 'zip', fileSize: '2.4 MB' }]
        },
        {
          id: `chap-${Date.now()}-2`,
          title: { fa: 'ماژول دوم: مهندسی پیشرفته و پیاده‌سازی', en: 'Module 2: Advanced Engineering' },
          durationSeconds: 3600,
          videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
          summary: { fa: 'پیاده‌سازی لایه‌های سیستم', en: 'Implementing system layers' },
          keyPoints: [{ fa: 'ساختار کد', en: 'Code structure' }],
          resources: [{ id: 'r2', title: { fa: 'اسلایدها', en: 'Slides' }, fileType: 'pdf', fileSize: '4.1 MB' }]
        },
        {
          id: `chap-${Date.now()}-3`,
          title: { fa: 'ماژول سوم: استقرار در مقیاس صنعتی', en: 'Module 3: Production Scale' },
          durationSeconds: 3600,
          videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
          summary: { fa: 'استقرار و بهینه‌سازی سرعت', en: 'Deployment and speed tuning' },
          keyPoints: [{ fa: 'بهینه‌سازی', en: 'Optimization' }],
          resources: [{ id: 'r3', title: { fa: 'داکر کامپوز', en: 'Docker Compose' }, fileType: 'zip', fileSize: '1.2 MB' }]
        }
      ]
    };

    createCourse(newCourseObj);
    setShowNewCourseModal(false);
    setNewTitleFa('');
    setNewTitleEn('');
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-1">
            <Lock className="h-3.5 w-3.5" />
            <span>مدیر ارشد سیستم: {currentUser.name} (Admin)</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            {UI_TEXT.adminTitle[language]}
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            {UI_TEXT.adminSubtitle[language]}
          </p>
        </div>

        <button
          onClick={resetAllData}
          className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs text-slate-400 hover:text-white hover:border-slate-700 transition-colors"
          title="بازنشانی داده‌های نمونه اولیه"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          <span>بازنشانی به داده‌های اولیه</span>
        </button>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total IRR Revenue */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-2">
          <div className="text-xs text-slate-400 font-medium">
            {UI_TEXT.totalRevenueIRR[language]}
          </div>
          <div className="text-2xl font-black text-cyan-400 font-mono tabular-nums">
            {formatPrice(totalRevenueIRR, 'IRR', language)}
          </div>
          <div className="text-[11px] text-slate-500">
            درگاه‌های زرین‌پال و کارت‌های شتاب
          </div>
        </div>

        {/* Total USD Revenue */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-2">
          <div className="text-xs text-slate-400 font-medium">
            {UI_TEXT.totalRevenueUSD[language]}
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono tabular-nums">
            {formatPrice(totalRevenueUSD, 'USD', language)}
          </div>
          <div className="text-[11px] text-slate-500">
            درگاه‌های Stripe و پرداخت بین‌المللی
          </div>
        </div>

        {/* Active Learners */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-2">
          <div className="text-xs text-slate-400 font-medium">
            {UI_TEXT.activeLearners[language]}
          </div>
          <div className="text-2xl font-black text-white font-mono tabular-nums">
            {allEnrolledUsersCount + 148} نفر
          </div>
          <div className="text-[11px] text-slate-500">
            دانشجویان دارای دسترسی مجاز
          </div>
        </div>

        {/* Stream Hours */}
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-2">
          <div className="text-xs text-slate-400 font-medium">
            {UI_TEXT.totalStreamHours[language]}
          </div>
          <div className="text-2xl font-black text-amber-400 font-mono tabular-nums">
            ۱,۸۴۰ ساعت
          </div>
          <div className="text-[11px] text-slate-500">
            استریم رمزنگاری شده AES-128
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex border-b border-slate-800 space-x-1 sm:space-x-4">
        {[
          { id: 'courses', label: UI_TEXT.tabCourses[language], icon: Layers },
          { id: 'orders', label: UI_TEXT.tabOrders[language], icon: ShoppingCart },
          { id: 'users', label: UI_TEXT.tabUsers[language], icon: Users },
          { id: 'security', label: UI_TEXT.tabSecurity[language], icon: ShieldCheck }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 border-b-2 px-4 py-3 text-xs sm:text-sm font-semibold transition-colors ${
                isActive
                  ? 'border-cyan-400 text-cyan-400 bg-slate-900/50'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: Courses Management */}
      {activeTab === 'courses' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">
              فهرست مسترکلاس‌ها و پکیج‌های دیجیتال
            </h3>
            <button
              onClick={() => setShowNewCourseModal(true)}
              className="flex items-center gap-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 px-4 py-2 text-xs font-semibold text-slate-950 transition-colors"
            >
              <Plus className="h-4 w-4" />
              <span>{UI_TEXT.newCourseBtn[language]}</span>
            </button>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/40">
            <table className="w-full text-right text-xs">
              <thead className="border-b border-slate-800 bg-slate-950/70 text-slate-400">
                <tr>
                  <th className="py-3 px-4">عنوان دوره</th>
                  <th className="py-3 px-4">دسته‌بندی</th>
                  <th className="py-3 px-4">طول دوره</th>
                  <th className="py-3 px-4">قیمت ریالی</th>
                  <th className="py-3 px-4">قیمت دلاری</th>
                  <th className="py-3 px-4 text-center">تعداد ثبت‌نام</th>
                  <th className="py-3 px-4 text-left">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {courses.map(course => (
                  <tr key={course.id} className="hover:bg-slate-900/60 transition-colors">
                    <td className="py-3.5 px-4 font-sans font-medium text-white max-w-xs truncate">
                      {course.title[language]}
                    </td>
                    <td className="py-3.5 px-4 text-slate-400 uppercase">
                      {course.category}
                    </td>
                    <td className="py-3.5 px-4 text-slate-300">
                      {formatDuration(course.totalDurationSeconds, language)}
                    </td>
                    <td className="py-3.5 px-4 text-cyan-400">
                      {formatPrice(course.priceIRR, 'IRR', language)}
                    </td>
                    <td className="py-3.5 px-4 text-emerald-400">
                      {formatPrice(course.priceUSD, 'USD', language)}
                    </td>
                    <td className="py-3.5 px-4 text-center text-slate-300">
                      {course.enrolledUserIds.length}
                    </td>
                    <td className="py-3.5 px-4 text-left font-sans">
                      <button
                        onClick={() => deleteCourse(course.id)}
                        className="rounded p-1.5 text-rose-400 hover:bg-rose-500/10 transition-colors"
                        title="حذف دوره"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Orders & Invoices */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          <h3 className="text-base font-bold text-white">
            دفتر کل سفارش‌ها، فاکتورها و تسویه‌ها
          </h3>

          <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/40">
            <table className="w-full text-right text-xs">
              <thead className="border-b border-slate-800 bg-slate-950/70 text-slate-400">
                <tr>
                  <th className="py-3 px-4">شناسه سفارش</th>
                  <th className="py-3 px-4">خریدار</th>
                  <th className="py-3 px-4">درگاه پردازش</th>
                  <th className="py-3 px-4">مبلغ پرداخت شده</th>
                  <th className="py-3 px-4">کد رهگیری</th>
                  <th className="py-3 px-4">تاریخ صدور</th>
                  <th className="py-3 px-4 text-left">فاکتور رسمی</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {orders.map(order => (
                  <tr key={order.id} className="hover:bg-slate-900/60 transition-colors">
                    <td className="py-3.5 px-4 text-cyan-400 font-bold">
                      {order.id}
                    </td>
                    <td className="py-3.5 px-4 font-sans text-slate-200">
                      {order.userName}
                    </td>
                    <td className="py-3.5 px-4 uppercase text-slate-300">
                      {order.gateway}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-white">
                      {formatPrice(order.total, order.currency, language)}
                    </td>
                    <td className="py-3.5 px-4 text-slate-400">
                      {order.trackingCode}
                    </td>
                    <td className="py-3.5 px-4 text-slate-500">
                      {new Date(order.createdAt).toLocaleDateString('fa-IR')}
                    </td>
                    <td className="py-3.5 px-4 text-left font-sans">
                      <button
                        onClick={() => setSelectedOrderForInvoice(order)}
                        className="flex items-center gap-1 rounded bg-slate-800 px-2.5 py-1 text-xs text-cyan-300 hover:bg-slate-700 transition-colors"
                      >
                        <FileText className="h-3 w-3" />
                        <span>مشاهده</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Users & Access Control */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          <h3 className="text-base font-bold text-white">
            مدیریت دسترسی کاربران به دوره‌ها
          </h3>

          <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h4 className="text-sm font-bold text-white">{currentUser.name}</h4>
                <p className="text-xs text-slate-400 font-mono">{currentUser.email}</p>
              </div>
              <span className="rounded bg-cyan-500/10 px-2.5 py-1 text-xs font-mono text-cyan-400">
                نقش: دانش‌پژوه (Learner)
              </span>
            </div>

            <div className="space-y-3">
              <h5 className="text-xs font-semibold text-slate-300">
                وضعیت دسترسی به تک تک دوره‌های آکادمی:
              </h5>

              <div className="space-y-2">
                {courses.map(course => {
                  const hasAccess = currentUser.enrolledCourseIds.includes(course.id);
                  return (
                    <div 
                      key={course.id}
                      className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950 p-3 text-xs"
                    >
                      <span className="text-white font-medium">{course.title[language]}</span>
                      
                      {hasAccess ? (
                        <div className="flex items-center gap-3">
                          <span className="text-emerald-400 font-semibold">دسترسی فعال</span>
                          <button
                            onClick={() => revokeCourseAccess(currentUser.id, course.id)}
                            className="rounded bg-rose-500/10 px-2.5 py-1 text-xs text-rose-400 hover:bg-rose-500/20"
                          >
                            {UI_TEXT.revokeAccess[language]}
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => grantCourseAccess(currentUser.id, course.id)}
                          className="rounded bg-cyan-500/10 px-2.5 py-1 text-xs text-cyan-400 hover:bg-cyan-500/20"
                        >
                          {UI_TEXT.grantAccess[language]}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Security & DRM Token Monitor */}
      {activeTab === 'security' && (
        <div className="space-y-4">
          <h3 className="text-base font-bold text-white">
            مانیتورینگ زنده توکن‌های استریم و نشست‌های امن (Session Tokens)
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-3 text-xs">
              <div className="flex items-center gap-2 font-bold text-cyan-400">
                <Key className="h-4 w-4" />
                <span>تنظیمات انقضای توکن استریم</span>
              </div>
              <p className="text-slate-400 leading-relaxed">
                مدت اعتبار هر توکن استریم: <strong>۱۵ دقیقه (۹۰۰ ثانیه)</strong>. پس از پایان زمان، پلیر به صورت خودکار با کلید اعتبارسنجی نشست درخواست توکن جدید می‌دهد تا از بازپخش و لینک‌ربایی غیرمجاز جلوگیری شود.
              </p>
              <div className="pt-2 text-slate-500 font-mono text-[11px]">
                الگوریتم رمزنگاری: AES-128-CBC با HLS Playlist Obfuscation
              </div>
            </div>

            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-5 space-y-3 text-xs">
              <div className="flex items-center gap-2 font-bold text-amber-400">
                <ShieldCheck className="h-4 w-4" />
                <span>واترمارک پویا و بازدارنده نشت</span>
              </div>
              <p className="text-slate-400 leading-relaxed">
                ایمیل کاربر (<span className="text-slate-200 font-mono">{currentUser.email}</span>) به همراه برچسب زمانی و هش نشست، هر ۹ ثانیه در موقعیت متفاوتی از پلیر شناور می‌شود تا هرگونه اسکرین‌رکورد حاوی هویت انتشاردهنده باشد.
              </p>
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-4">
            <h4 className="text-xs font-bold text-slate-300 mb-3">
              نشست‌های فعال پلیر در حال حاضر
            </h4>
            <div className="space-y-2 text-xs font-mono">
              <div className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950 p-3">
                <div>
                  <span className="text-cyan-400 font-bold">tk_8f92a10c</span>
                  <span className="text-slate-400 mx-2">·</span>
                  <span className="text-slate-200 font-sans">{currentUser.email}</span>
                  <span className="text-slate-500 ml-2">IP: 5.127.84.19</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-emerald-400 text-[11px]">متصل (استریم فعال)</span>
                  <span className="text-slate-500">انقضا: ۱۲:۴۵</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* New Course Modal */}
      {showNewCourseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-2xl border border-slate-800 bg-slate-900 p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h4 className="text-sm font-bold text-white">ایجاد مسترکلاس یا پکیج جدید</h4>
              <button onClick={() => setShowNewCourseModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateCourseSubmit} className="space-y-3">
              <div>
                <label className="text-slate-400 block mb-1">عنوان دوره (فارسی)</label>
                <input
                  type="text"
                  required
                  value={newTitleFa}
                  onChange={(e) => setNewTitleFa(e.target.value)}
                  placeholder="مسترکلاس..."
                  className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Title (English)</label>
                <input
                  type="text"
                  required
                  value={newTitleEn}
                  onChange={(e) => setNewTitleEn(e.target.value)}
                  placeholder="Masterclass..."
                  className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">قیمت به تومان (IRR)</label>
                  <input
                    type="number"
                    value={newPriceIRR}
                    onChange={(e) => setNewPriceIRR(Number(e.target.value))}
                    className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-white font-mono focus:border-cyan-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">قیمت به دلار (USD $)</label>
                  <input
                    type="number"
                    value={newPriceUSD}
                    onChange={(e) => setNewPriceUSD(Number(e.target.value))}
                    className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-white font-mono focus:border-cyan-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">دسته‌بندی</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                  >
                    <option value="llm">مدل‌های زبانی (LLM)</option>
                    <option value="vision">بینایی و دیفیوژن</option>
                    <option value="systems">زیرساخت و پایپ‌لاین‌ها</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">نام مدرس</label>
                  <input
                    type="text"
                    value={newInstructorName}
                    onChange={(e) => setNewInstructorName(e.target.value)}
                    className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewCourseModal(false)}
                  className="rounded-lg border border-slate-800 px-4 py-2 text-slate-400 hover:text-white"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-cyan-500 hover:bg-cyan-400 px-5 py-2 font-bold text-slate-950"
                >
                  ثبت و انتشار دوره
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
