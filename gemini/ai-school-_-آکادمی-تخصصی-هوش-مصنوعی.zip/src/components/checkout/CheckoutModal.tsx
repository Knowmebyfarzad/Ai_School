import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatPrice, toPersianDigits, UI_TEXT } from '../../utils/i18n';
import { Order } from '../../types';
import { 
  X, 
  ShieldCheck, 
  CreditCard, 
  Lock, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  FileText, 
  Play, 
  RefreshCw,
  Building2,
  Globe2
} from 'lucide-react';

export const CheckoutModal: React.FC = () => {
  const { 
    language, 
    currency, 
    setCurrency,
    selectedCourseForCheckout: course, 
    setSelectedCourseForCheckout,
    enrollInCourse,
    openClassroom,
    setSelectedOrderForInvoice
  } = useApp();

  if (!course) return null;

  const [activeGateway, setActiveGateway] = useState<'zarinpal' | 'stripe'>(
    currency === 'IRR' ? 'zarinpal' : 'stripe'
  );

  // Iranian Shetab fields
  const [iranCardNumber, setIranCardNumber] = useState('6037-9918-5421-8842');
  const [iranCvv2, setIranCvv2] = useState('742');
  const [iranExpMonth, setIranExpMonth] = useState('08');
  const [iranExpYear, setIranExpYear] = useState('06');
  const [dynamicOtp, setDynamicOtp] = useState('');
  const [otpRequested, setOtpRequested] = useState(false);
  const [otpTimer, setOtpTimer] = useState(120);

  // Stripe fields
  const [stripeCardNumber, setStripeCardNumber] = useState('4242 •••• •••• 4242');
  const [stripeExp, setStripeExp] = useState('12/28');
  const [stripeCvc, setStripeCvc] = useState('892');
  const [stripeCountry, setStripeCountry] = useState('United States');

  // Coupon
  const [couponCode, setCouponCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [couponError, setCouponError] = useState('');
  const [couponSuccess, setCouponSuccess] = useState('');

  // Payment state
  const [isProcessing, setIsProcessing] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  // Calculations
  const basePrice = currency === 'IRR' ? course.priceIRR : course.priceUSD;
  const discountAmount = Math.round((basePrice * discountPercent) / 100);
  const subtotalAfterDiscount = basePrice - discountAmount;
  const taxAmount = currency === 'USD' ? +(subtotalAfterDiscount * 0.05).toFixed(2) : 0;
  const finalTotal = subtotalAfterDiscount + taxAmount;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    setCouponSuccess('');

    const clean = couponCode.trim().toUpperCase();
    if (clean === 'AISCHOOL20') {
      setDiscountPercent(20);
      setCouponSuccess(language === 'fa' ? 'کد تخفیف ۲۰٪ با موفقیت اعمال شد!' : '20% discount code applied!');
    } else if (clean === 'WELCOME10') {
      setDiscountPercent(10);
      setCouponSuccess(language === 'fa' ? 'کد تخفیف ۱۰٪ با موفقیت اعمال شد!' : '10% discount code applied!');
    } else {
      setCouponError(language === 'fa' ? 'کد تخفیف وارد شده معتبر نیست.' : 'Invalid coupon code.');
    }
  };

  const handleRequestOtp = () => {
    setOtpRequested(true);
    setDynamicOtp('849102'); // Simulated OTP autofill
    setOtpTimer(120);
  };

  const handleExecutePayment = () => {
    setIsProcessing(true);

    setTimeout(() => {
      const cardMask = activeGateway === 'zarinpal'
        ? `۶۰۳۷-۹۹**-****-${iranCardNumber.slice(-4) || '۸۸۴۲'}`
        : `4242-****-****-${stripeCardNumber.slice(-4) || '4242'}`;

      const order = enrollInCourse(
        course, 
        activeGateway, 
        discountAmount, 
        couponSuccess ? couponCode : undefined,
        cardMask
      );

      setIsProcessing(false);
      setCompletedOrder(order);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-950/85 backdrop-blur-md">
      <div 
        className="relative w-full max-w-2xl rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4 bg-slate-950/60">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <Lock className="h-4 w-4 text-cyan-400" />
            <span>{UI_TEXT.checkoutTitle[language]}</span>
          </div>

          <button
            onClick={() => setSelectedCourseForCheckout(null)}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* If Order is Completed -> Success Screen */}
        {completedOrder ? (
          <div className="p-6 sm:p-8 text-center space-y-6">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/30">
              <CheckCircle2 className="h-10 w-10" />
            </div>

            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-white">
                {language === 'fa' ? 'پرداخت با موفقیت انجام شد!' : 'Payment Completed Successfully!'}
              </h3>
              <p className="mt-2 text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                {language === 'fa'
                  ? 'دسترسی شما به دوره و فایل‌های پروژه بلافاصله فعال شد. رسید رسمی و فاکتور خرید صادر گردید.'
                  : 'Your course and project file access has been unlocked immediately. An official tax invoice has been generated.'}
              </p>
            </div>

            {/* Receipt Summary Card */}
            <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4 text-xs text-slate-300 space-y-2.5 max-w-md mx-auto text-right">
              <div className="flex justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">{language === 'fa' ? 'شناسه سفارش' : 'Order ID'}:</span>
                <span className="font-mono text-cyan-400 font-semibold">{completedOrder.id}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">{language === 'fa' ? 'کد رهگیری تراکنش' : 'Tracking Ref'}:</span>
                <span className="font-mono text-slate-200">{completedOrder.transactionRef}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">{language === 'fa' ? 'مبلغ پرداختی' : 'Amount Paid'}:</span>
                <span className="font-mono font-bold text-emerald-400">
                  {formatPrice(completedOrder.total, completedOrder.currency, language)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">{language === 'fa' ? 'درگاه پردازش' : 'Gateway'}:</span>
                <span className="font-medium text-slate-200 uppercase">{completedOrder.gateway}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <button
                onClick={() => {
                  setSelectedCourseForCheckout(null);
                  openClassroom(course.id);
                }}
                className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 px-6 py-2.5 text-xs font-semibold text-slate-950 shadow-md shadow-cyan-500/20 transition-colors whitespace-nowrap"
              >
                <Play className="h-4 w-4 fill-current" />
                <span>{language === 'fa' ? 'شروع یادگیری و تماشای ویدئو' : 'Start Watching Masterclass'}</span>
              </button>

              <button
                onClick={() => {
                  setSelectedOrderForInvoice(completedOrder);
                }}
                className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-lg border border-slate-700 bg-slate-800 hover:bg-slate-700 px-5 py-2.5 text-xs font-medium text-slate-200 transition-colors whitespace-nowrap"
              >
                <FileText className="h-4 w-4 text-cyan-400" />
                <span>{UI_TEXT.viewInvoice[language]}</span>
              </button>
            </div>
          </div>
        ) : (
          /* Payment Form */
          <div className="p-6 sm:p-8 space-y-6">
            
            {/* Selected Course Summary */}
            <div className="flex items-center gap-3.5 rounded-xl border border-slate-800 bg-slate-950/60 p-3.5">
              <img
                src={course.thumbnail}
                alt={course.title[language]}
                className="h-14 w-24 rounded-lg object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="flex-1 min-w-0">
                <h4 className="text-xs sm:text-sm font-bold text-white truncate">
                  {course.title[language]}
                </h4>
                <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-400">
                  <span>~۳ ساعت آموزش عمیق</span>
                  <span aria-hidden="true">·</span>
                  <span>{course.instructor.name[language]}</span>
                </div>
              </div>
            </div>

            {/* Gateway Selection Tabs */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-2.5">
                {UI_TEXT.selectGateway[language]}
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* ZarinPal / Iranian Gateway */}
                <button
                  type="button"
                  onClick={() => {
                    setActiveGateway('zarinpal');
                    setCurrency('IRR');
                  }}
                  className={`flex items-start gap-3 rounded-xl border p-3.5 text-right transition-all ${
                    activeGateway === 'zarinpal'
                      ? 'border-cyan-500 bg-cyan-950/20 ring-1 ring-cyan-500/50'
                      : 'border-slate-800 bg-slate-950/40 hover:border-slate-700'
                  }`}
                >
                  <Building2 className={`h-5 w-5 mt-0.5 ${activeGateway === 'zarinpal' ? 'text-cyan-400' : 'text-slate-500'}`} />
                  <div>
                    <span className="text-xs font-bold text-white block">
                      {UI_TEXT.gatewayZarinpal[language]}
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5 block">
                      کارت‌های عضو شتاب ایران با رمز پویا
                    </span>
                  </div>
                </button>

                {/* Stripe / International Gateway */}
                <button
                  type="button"
                  onClick={() => {
                    setActiveGateway('stripe');
                    setCurrency('USD');
                  }}
                  className={`flex items-start gap-3 rounded-xl border p-3.5 text-right transition-all ${
                    activeGateway === 'stripe'
                      ? 'border-cyan-500 bg-cyan-950/20 ring-1 ring-cyan-500/50'
                      : 'border-slate-800 bg-slate-950/40 hover:border-slate-700'
                  }`}
                >
                  <Globe2 className={`h-5 w-5 mt-0.5 ${activeGateway === 'stripe' ? 'text-cyan-400' : 'text-slate-500'}`} />
                  <div>
                    <span className="text-xs font-bold text-white block">
                      {UI_TEXT.gatewayStripe[language]}
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5 block">
                      Visa / Mastercard / دلاری‌شو
                    </span>
                  </div>
                </button>
              </div>
            </div>

            {/* Gateway Card Fields Simulation */}
            {activeGateway === 'zarinpal' ? (
              <div className="rounded-xl border border-slate-800 bg-slate-950/50 p-4 space-y-3.5 text-xs">
                <div>
                  <label className="text-slate-400 mb-1 block">شماره ۱۶ رقمی کارت بانکی (شتاب)</label>
                  <input
                    type="text"
                    value={iranCardNumber}
                    onChange={(e) => setIranCardNumber(e.target.value)}
                    placeholder="xxxx-xxxx-xxxx-xxxx"
                    className="w-full rounded-lg border border-slate-800 bg-slate-900 px-3 py-2 text-white font-mono focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-3 gap-2.5">
                  <div>
                    <label className="text-slate-400 mb-1 block">کد CVV2</label>
                    <input
                      type="password"
                      maxLength={4}
                      value={iranCvv2}
                      onChange={(e) => setIranCvv2(e.target.value)}
                      className="w-full rounded-lg border border-slate-800 bg-slate-900 px-3 py-2 text-white font-mono text-center focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 mb-1 block">ماه انقضا</label>
                    <input
                      type="text"
                      maxLength={2}
                      value={iranExpMonth}
                      onChange={(e) => setIranExpMonth(e.target.value)}
                      className="w-full rounded-lg border border-slate-800 bg-slate-900 px-3 py-2 text-white font-mono text-center focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 mb-1 block">سال انقضا</label>
                    <input
                      type="text"
                      maxLength={2}
                      value={iranExpYear}
                      onChange={(e) => setIranExpYear(e.target.value)}
                      className="w-full rounded-lg border border-slate-800 bg-slate-900 px-3 py-2 text-white font-mono text-center focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Dynamic OTP field */}
                <div className="flex gap-2 items-end">
                  <div className="flex-1">
                    <label className="text-slate-400 mb-1 block">رمز اینترنتی پویا</label>
                    <input
                      type="text"
                      value={dynamicOtp}
                      onChange={(e) => setDynamicOtp(e.target.value)}
                      placeholder="کد ۶ رقمی پیامک شده"
                      className="w-full rounded-lg border border-slate-800 bg-slate-900 px-3 py-2 text-white font-mono tracking-widest focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleRequestOtp}
                    className="rounded-lg border border-cyan-500/50 bg-cyan-950/40 px-3.5 py-2 text-xs font-medium text-cyan-300 hover:bg-cyan-900/40 transition-colors whitespace-nowrap"
                  >
                    {otpRequested ? 'رمز ارسال شد (849102)' : 'دریافت رمز پویا'}
                  </button>
                </div>
              </div>
            ) : (
              /* Stripe Card Inputs */
              <div className="rounded-xl border border-slate-800 bg-slate-950/50 p-4 space-y-3.5 text-xs">
                <div>
                  <label className="text-slate-400 mb-1 block">Card Number (Visa / Mastercard)</label>
                  <input
                    type="text"
                    value={stripeCardNumber}
                    onChange={(e) => setStripeCardNumber(e.target.value)}
                    className="w-full rounded-lg border border-slate-800 bg-slate-900 px-3 py-2 text-white font-mono focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-400 mb-1 block">Expires (MM/YY)</label>
                    <input
                      type="text"
                      value={stripeExp}
                      onChange={(e) => setStripeExp(e.target.value)}
                      className="w-full rounded-lg border border-slate-800 bg-slate-900 px-3 py-2 text-white font-mono text-center focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 mb-1 block">CVC / CVV</label>
                    <input
                      type="password"
                      maxLength={4}
                      value={stripeCvc}
                      onChange={(e) => setStripeCvc(e.target.value)}
                      className="w-full rounded-lg border border-slate-800 bg-slate-900 px-3 py-2 text-white font-mono text-center focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-slate-400 mb-1 block">Billing Country / Region</label>
                  <select
                    value={stripeCountry}
                    onChange={(e) => setStripeCountry(e.target.value)}
                    className="w-full rounded-lg border border-slate-800 bg-slate-900 px-3 py-2 text-white focus:border-cyan-500 focus:outline-none"
                  >
                    <option value="United States">United States (5% Digital Tax)</option>
                    <option value="United Kingdom">United Kingdom</option>
                    <option value="Germany">Germany (EU VAT)</option>
                    <option value="United Arab Emirates">United Arab Emirates</option>
                    <option value="Canada">Canada</option>
                  </select>
                </div>
              </div>
            )}

            {/* Coupon Code Section */}
            <div>
              <form onSubmit={handleApplyCoupon} className="flex gap-2">
                <input
                  type="text"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  placeholder={UI_TEXT.couponPrompt[language]}
                  className="flex-1 rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-white focus:border-cyan-500 focus:outline-none uppercase"
                />
                <button
                  type="submit"
                  className="rounded-lg border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-medium text-slate-200 hover:bg-slate-700 transition-colors whitespace-nowrap"
                >
                  {UI_TEXT.applyCoupon[language]}
                </button>
              </form>

              {couponSuccess && (
                <p className="mt-1.5 text-xs text-emerald-400">{couponSuccess}</p>
              )}
              {couponError && (
                <p className="mt-1.5 text-xs text-rose-400">{couponError}</p>
              )}
            </div>

            {/* Price Ledger Calculation */}
            <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-4 space-y-2 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>{UI_TEXT.subtotal[language]}:</span>
                <span className="font-mono tabular-nums">{formatPrice(basePrice, currency, language)}</span>
              </div>

              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>{UI_TEXT.discount[language]} ({discountPercent}٪):</span>
                  <span className="font-mono tabular-nums">- {formatPrice(discountAmount, currency, language)}</span>
                </div>
              )}

              {taxAmount > 0 && (
                <div className="flex justify-between text-slate-400">
                  <span>{UI_TEXT.tax[language]} (5%):</span>
                  <span className="font-mono tabular-nums">+{formatPrice(taxAmount, currency, language)}</span>
                </div>
              )}

              <div className="flex justify-between border-t border-slate-800 pt-2.5 text-sm font-bold text-white">
                <span>{UI_TEXT.finalTotal[language]}:</span>
                <span className="font-mono text-cyan-400 tabular-nums">
                  {formatPrice(finalTotal, currency, language)}
                </span>
              </div>
            </div>

            {/* Security Notice */}
            <div className="flex items-center gap-2 text-[11px] text-slate-400">
              <Lock className="h-3.5 w-3.5 text-slate-500 shrink-0" />
              <span>{UI_TEXT.secureNotice[language]}</span>
            </div>

            {/* Execute Payment Button */}
            <button
              type="button"
              disabled={isProcessing}
              onClick={handleExecutePayment}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 py-3 text-sm font-bold text-slate-950 shadow-lg shadow-cyan-500/20 transition-all disabled:opacity-50 whitespace-nowrap"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  <span>
                    {language === 'fa' ? 'در حال برقراری ارتباط امن با درگاه...' : 'Processing Secure Transaction...'}
                  </span>
                </>
              ) : (
                <>
                  <ShieldCheck className="h-4 w-4" />
                  <span>
                    {UI_TEXT.payButton[language]} ({formatPrice(finalTotal, currency, language)})
                  </span>
                </>
              )}
            </button>

          </div>
        )}

      </div>
    </div>
  );
};
