import React from 'react';
import { useApp } from '../../context/AppContext';
import { UI_TEXT } from '../../utils/i18n';
import { 
  ShieldCheck, 
  BookOpen, 
  Layers, 
  Settings, 
  User as UserIcon, 
  Globe, 
  DollarSign
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { 
    language, 
    setLanguage, 
    currency, 
    setCurrency, 
    currentView, 
    setCurrentView,
    currentUser,
    orders
  } = useApp();

  const enrolledCount = currentUser.enrolledCourseIds.length;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button 
            onClick={() => setCurrentView('catalog')}
            className="group flex items-center gap-2.5 text-left focus:outline-none"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 shadow-md shadow-cyan-500/20">
              <ShieldCheck className="h-5 w-5 text-slate-950" />
            </div>
            <div className="flex flex-col">
              <span className="text-base font-bold tracking-tight text-white group-hover:text-cyan-400 transition-colors whitespace-nowrap">
                {UI_TEXT.brandName[language]}
              </span>
              <span className="text-[11px] font-mono text-slate-400 -mt-0.5 tracking-wider hidden sm:block">
                {UI_TEXT.brandTagline[language]}
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: 4-5 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          <button
            onClick={() => setCurrentView('catalog')}
            className={`whitespace-nowrap transition-colors hover:text-white ${
              currentView === 'catalog' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            {UI_TEXT.navCourses[language]}
          </button>

          <button
            onClick={() => {
              setCurrentView('catalog');
              setTimeout(() => {
                const bundleSection = document.getElementById('bundles-section');
                bundleSection?.scrollIntoView({ behavior: 'smooth' });
              }, 50);
            }}
            className="whitespace-nowrap transition-colors hover:text-white"
          >
            {UI_TEXT.navPackages[language]}
          </button>

          <button
            onClick={() => setCurrentView('library')}
            className={`relative flex items-center gap-1.5 whitespace-nowrap transition-colors hover:text-white ${
              currentView === 'library' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            <BookOpen className="h-4 w-4" />
            <span>{UI_TEXT.navLibrary[language]}</span>
            {enrolledCount > 0 && (
              <span className="flex h-4 min-w-4 items-center justify-center rounded-full bg-cyan-500/20 px-1 text-[10px] font-mono text-cyan-300">
                {enrolledCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setCurrentView('admin')}
            className={`flex items-center gap-1.5 whitespace-nowrap transition-colors hover:text-white ${
              currentView === 'admin' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            <Settings className="h-4 w-4" />
            <span>{UI_TEXT.navAdmin[language]}</span>
          </button>
        </nav>

        {/* Zone 3: 1 primary action area: Language, Currency & User */}
        <div className="flex items-center gap-2.5 sm:gap-3.5 shrink-0">
          
          {/* Currency Toggle */}
          <div className="flex items-center rounded-lg border border-slate-800 bg-slate-900/80 p-0.5">
            <button
              onClick={() => setCurrency('IRR')}
              title="تومان (ایران)"
              className={`rounded-md px-2 py-1 text-xs font-medium transition-colors ${
                currency === 'IRR'
                  ? 'bg-slate-800 text-cyan-400 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              تومان
            </button>
            <button
              onClick={() => setCurrency('USD')}
              title="US Dollars ($)"
              className={`rounded-md px-2 py-1 text-xs font-mono font-medium transition-colors ${
                currency === 'USD'
                  ? 'bg-slate-800 text-cyan-400 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              $ USD
            </button>
          </div>

          {/* Language Toggle */}
          <button
            onClick={() => setLanguage(language === 'fa' ? 'en' : 'fa')}
            className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900/80 px-2.5 py-1 text-xs font-medium text-slate-300 hover:border-slate-700 hover:text-white transition-colors"
            title="تغییر زبان / Switch Language"
          >
            <Globe className="h-3.5 w-3.5 text-slate-400" />
            <span className="font-mono uppercase">{language === 'fa' ? 'EN' : 'فا'}</span>
          </button>

          {/* User Account / Library Link */}
          <button
            onClick={() => setCurrentView(currentView === 'library' ? 'catalog' : 'library')}
            className="flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-900/60 p-1 pl-2.5 sm:px-2.5 hover:border-slate-700 transition-colors"
            title={currentUser.email}
          >
            <img 
              src={currentUser.avatar} 
              alt={currentUser.name} 
              className="h-6 w-6 rounded-full object-cover ring-1 ring-cyan-500/30"
              referrerPolicy="no-referrer"
            />
            <span className="hidden lg:block text-xs font-medium text-slate-200 max-w-[110px] truncate">
              {currentUser.name}
            </span>
          </button>

          {/* Mobile Admin / Menu Button */}
          <div className="flex md:hidden">
            <button
              onClick={() => setCurrentView(currentView === 'admin' ? 'catalog' : 'admin')}
              className="rounded-lg border border-slate-800 p-1.5 text-slate-300 hover:text-white"
              title="Admin Console"
            >
              <Settings className="h-4 w-4" />
            </button>
          </div>
        </div>

      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="flex md:hidden items-center justify-around border-t border-slate-800/60 bg-slate-950 px-2 py-2 text-xs text-slate-300">
        <button
          onClick={() => setCurrentView('catalog')}
          className={`px-3 py-1 ${currentView === 'catalog' ? 'text-cyan-400 font-semibold' : ''}`}
        >
          {UI_TEXT.navCourses[language]}
        </button>
        <button
          onClick={() => setCurrentView('library')}
          className={`flex items-center gap-1 px-3 py-1 ${currentView === 'library' ? 'text-cyan-400 font-semibold' : ''}`}
        >
          <BookOpen className="h-3.5 w-3.5" />
          <span>{UI_TEXT.navLibrary[language]}</span>
          {enrolledCount > 0 && <span className="text-cyan-400">({enrolledCount})</span>}
        </button>
        <button
          onClick={() => setCurrentView('admin')}
          className={`flex items-center gap-1 px-3 py-1 ${currentView === 'admin' ? 'text-cyan-400 font-semibold' : ''}`}
        >
          <Settings className="h-3.5 w-3.5" />
          <span>{UI_TEXT.navAdmin[language]}</span>
        </button>
      </div>
    </header>
  );
};
