import React from 'react';
import { useApp } from '../../context/AppContext';
import { UI_TEXT } from '../../utils/i18n';
import { ShieldCheck, Lock, CreditCard, Award } from 'lucide-react';

export const Footer: React.FC = () => {
  const { language, setCurrentView } = useApp();

  return (
    <footer className="border-t border-slate-800/80 bg-slate-950 py-12 text-xs text-slate-400">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Brand Info */}
          <div className="space-y-3 md:col-span-2">
            <div className="flex items-center gap-2 text-white font-bold text-sm">
              <ShieldCheck className="h-4 w-4 text-cyan-400" />
              <span>{UI_TEXT.brandName[language]}</span>
            </div>
            <p className="text-slate-400 leading-relaxed max-w-md">
              پلتفرم مرجع آموزش‌های تخصصی هوش مصنوعی در قالب مسترکلاس‌های فشرده ۳ ساعته. مجهز به پلیر تحت وب امن با واترمارک پویا، درگاه‌های پرداخت ریالی و دلاری، و صدور گواهی رسمی پایان دوره.
            </p>
            <div className="flex items-center gap-4 text-[11px] text-slate-500 font-mono">
              <span>نسخه سامانه: v1.0.0</span>
              <span>·</span>
              <span>پروتکل امنیتی: AES-128 DRM</span>
            </div>
          </div>

          {/* Quick links */}
          <div className="space-y-2">
            <h4 className="text-white font-semibold text-xs mb-3">دسترسی سریع</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => setCurrentView('catalog')} className="hover:text-cyan-400 transition-colors">
                  کاتالوگ دوره‌ها
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('library')} className="hover:text-cyan-400 transition-colors">
                  کتابخانه من (دوره‌های من)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('admin')} className="hover:text-cyan-400 transition-colors">
                  پنل مدیریت و حسابداری
                </button>
              </li>
            </ul>
          </div>

          {/* Compliance & Legal */}
          <div className="space-y-2">
            <h4 className="text-white font-semibold text-xs mb-3">امنیت و قوانین</h4>
            <div className="space-y-1.5 text-[11px] text-slate-400">
              <p>اطلاعات پرداخت توسط درگاه شاپرک و Stripe پردازش می‌شود.</p>
              <p>کپی‌برداری یا بازنشر ویدئوها به دلیل واترمارک هویتی پیگرد دارد.</p>
              <p>پشتیبانی: support@aischool.ir</p>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="border-t border-slate-800/80 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            © {new Date().getFullYear()} {UI_TEXT.brandName[language]}. تمامی حقوق مادی و معنوی محفوظ است.
          </div>
          <div className="flex items-center gap-4">
            <span>شرایط استفاده</span>
            <span>·</span>
            <span>حریم خصوصی</span>
            <span>·</span>
            <span>امنیت استریم</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
