import React from 'react';
import { useApp } from '../../context/AppContext';
import { UI_TEXT } from '../../utils/i18n';
import { Play, Sparkles, Shield, Clock, Award, ArrowUpRight } from 'lucide-react';

export const HeroBanner: React.FC = () => {
  const { language, courses, openClassroom, setSelectedCourseForCheckout } = useApp();
  
  const bundle = courses.find(c => c.isBundle) || courses[0];
  const featured = courses[0];

  return (
    <section className="relative overflow-hidden border-b border-slate-800 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 py-12 sm:py-16 lg:py-20">
      {/* Background radial glow */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-25">
        <div className="h-[450px] w-[650px] rounded-full bg-cyan-600/30 blur-[130px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Top Kicker - Clean unboxed text metadata */}
        <div className="flex items-center gap-2 text-xs font-medium text-cyan-400 mb-4 tracking-wide">
          <span>{UI_TEXT.heroBadge[language]}</span>
          <span aria-hidden="true">·</span>
          <span>۳ ساعت آموزش فشرده به ازای هر دوره</span>
          <span aria-hidden="true">·</span>
          <span>پرداخت یکباره</span>
        </div>

        {/* 2-Column Split Hero Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Column 1: Editorial Headline & Copy */}
          <div className="lg:col-span-7 flex flex-col items-start">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-[1.25] text-balance">
              {UI_TEXT.heroTitle[language]}
            </h1>

            <p className="mt-5 text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl">
              {UI_TEXT.heroSubtitle[language]}
            </p>

            {/* CTAs */}
            <div className="mt-8 flex flex-wrap items-center gap-3.5">
              <button
                onClick={() => {
                  const catalogElem = document.getElementById('catalog-grid');
                  catalogElem?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="flex items-center gap-2 rounded-lg bg-cyan-500 px-5 py-2.5 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/20 hover:bg-cyan-400 transition-colors whitespace-nowrap"
              >
                <span>{UI_TEXT.heroCtaBrowse[language]}</span>
                <ArrowUpRight className="h-4 w-4" />
              </button>

              <button
                onClick={() => setSelectedCourseForCheckout(bundle)}
                className="flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-900/80 px-5 py-2.5 text-sm font-medium text-slate-200 hover:border-slate-600 hover:bg-slate-800 transition-colors whitespace-nowrap"
              >
                <Award className="h-4 w-4 text-amber-400" />
                <span>{UI_TEXT.heroCtaBundle[language]}</span>
              </button>
            </div>

            {/* Security Guarantee Note */}
            <div className="mt-8 flex flex-wrap items-center gap-4 text-xs text-slate-400 border-t border-slate-800/80 pt-4 w-full">
              <div className="flex items-center gap-1.5">
                <Shield className="h-3.5 w-3.5 text-cyan-400" />
                <span>پلیر محافظت‌شده با واترمارک پویا</span>
              </div>
              <span aria-hidden="true" className="text-slate-600 hidden sm:inline">·</span>
              <div className="flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5 text-emerald-400" />
                <span>دسترسی دائمی بدون حق اشتراک ماهانه</span>
              </div>
            </div>
          </div>

          {/* Column 2: Spotlight Masterclass Visual Card */}
          <div className="lg:col-span-5">
            <div className="group relative rounded-xl border border-slate-800 bg-slate-900/60 p-2 shadow-2xl backdrop-blur-sm transition-all hover:border-slate-700">
              
              <div className="relative aspect-video overflow-hidden rounded-lg bg-slate-950">
                <img
                  src={featured.thumbnail}
                  alt={featured.title[language]}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                
                {/* Floating Preview Play Button */}
                <button
                  onClick={() => openClassroom(featured.id)}
                  className="absolute inset-0 flex items-center justify-center group/btn"
                  title="پیش‌نمایش ویدئو"
                >
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-cyan-500/90 text-slate-950 shadow-xl backdrop-blur-md transition-transform group-hover/btn:scale-110">
                    <Play className="h-6 w-6 fill-current translate-x-0.5" />
                  </div>
                </button>

                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-slate-300">
                  <span className="rounded bg-slate-950/80 px-2 py-0.5 font-mono text-[11px] backdrop-blur-sm">
                    پیش‌نمایش رایگان · ماژول ۱
                  </span>
                  <span className="font-mono text-cyan-300">
                    ۳ ساعت و ۱۰ دقیقه
                  </span>
                </div>
              </div>

              <div className="p-4">
                <h3 className="text-base font-bold text-white line-clamp-1">
                  {featured.title[language]}
                </h3>
                <p className="mt-1 text-xs text-slate-400 line-clamp-2 leading-relaxed">
                  {featured.description[language]}
                </p>
                <div className="mt-3 flex items-center justify-between pt-3 border-t border-slate-800/80 text-xs">
                  <div className="flex items-center gap-2">
                    <img
                      src={featured.instructor.avatar}
                      alt={featured.instructor.name[language]}
                      className="h-6 w-6 rounded-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <span className="text-slate-300 font-medium">{featured.instructor.name[language]}</span>
                  </div>
                  <button
                    onClick={() => openClassroom(featured.id)}
                    className="text-cyan-400 hover:text-cyan-300 font-medium transition-colors"
                  >
                    شروع تماشا ←
                  </button>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* 4-Column Proof & Metric Strip */}
        <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-4 border-t border-slate-800/80 pt-8">
          <div className="flex flex-col">
            <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono tabular-nums">
              +۱۵
            </span>
            <span className="text-xs text-slate-400 mt-1">
              {UI_TEXT.statsRuntimes[language]}
            </span>
          </div>

          <div className="flex flex-col">
            <span className="text-2xl sm:text-3xl font-extrabold text-cyan-400 font-mono tabular-nums">
              +۱,۲۵۰
            </span>
            <span className="text-xs text-slate-400 mt-1">
              {UI_TEXT.statsStudents[language]}
            </span>
          </div>

          <div className="flex flex-col">
            <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
              ۱۰۰٪
            </span>
            <span className="text-xs text-slate-400 mt-1">
              {UI_TEXT.statsGuarantee[language]}
            </span>
          </div>

          <div className="flex flex-col">
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono">
              AES-128
            </span>
            <span className="text-xs text-slate-400 mt-1">
              {UI_TEXT.statsSecurity[language]}
            </span>
          </div>
        </div>

      </div>
    </section>
  );
};
