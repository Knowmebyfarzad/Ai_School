import React from 'react';
import { useApp } from '../../context/AppContext';
import { formatDuration, formatPrice, formatPlaybackTime, UI_TEXT } from '../../utils/i18n';
import { 
  X, 
  Clock, 
  CheckCircle, 
  Layers, 
  FileText, 
  ShieldCheck, 
  Play, 
  Award,
  Video
} from 'lucide-react';

export const CourseDetailsModal: React.FC = () => {
  const { 
    language, 
    currency, 
    currentUser, 
    selectedCourseForDetails: course, 
    setSelectedCourseForDetails, 
    setSelectedCourseForCheckout,
    openClassroom 
  } = useApp();

  if (!course) return null;

  const isEnrolled = currentUser.enrolledCourseIds.includes(course.id);
  const currentPrice = currency === 'IRR' ? course.priceIRR : course.priceUSD;
  const originalPrice = currency === 'IRR' ? course.originalPriceIRR : course.originalPriceUSD;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-950/80 backdrop-blur-md">
      <div 
        className="relative w-full max-w-4xl rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden my-8"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header Bar */}
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4 bg-slate-950/60">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="font-mono text-cyan-400 uppercase tracking-wider">{course.category}</span>
            <span aria-hidden="true">·</span>
            <span>{formatDuration(course.totalDurationSeconds, language)}</span>
            <span aria-hidden="true">·</span>
            <span>{course.chapters.length} {UI_TEXT.modulesCount[language]}</span>
          </div>

          <button
            onClick={() => setSelectedCourseForDetails(null)}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="max-h-[80vh] overflow-y-auto p-6 sm:p-8 space-y-8">
          
          {/* Main Title & Subtitle */}
          <div>
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-white leading-snug">
              {course.title[language]}
            </h2>
            <p className="mt-3 text-sm text-slate-300 leading-relaxed">
              {course.subtitle[language]}
            </p>
          </div>

          {/* Video Preview Teaser Box */}
          <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
            <video
              src={course.previewVideoUrl}
              controls
              className="h-full w-full object-cover"
              poster={course.thumbnail}
            />
            <div className="absolute top-3 left-3 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded text-xs text-cyan-300 flex items-center gap-1.5">
              <Video className="h-3.5 w-3.5" />
              <span>{UI_TEXT.previewVideo[language]}</span>
            </div>
          </div>

          {/* Pricing & Fast Checkout Strip */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-950/70 p-5">
            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black text-white font-mono tabular-nums">
                  {formatPrice(currentPrice, currency, language)}
                </span>
                {originalPrice > currentPrice && (
                  <span className="text-sm text-slate-500 line-through font-mono tabular-nums">
                    {formatPrice(originalPrice, currency, language)}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-1">
                دسترسی همیشگی، بدون اشتراک ماهانه · شامل کلیه آپدیت‌ها و کدهای سورس
              </p>
            </div>

            <div className="w-full sm:w-auto flex gap-3">
              {isEnrolled ? (
                <button
                  onClick={() => {
                    setSelectedCourseForDetails(null);
                    openClassroom(course.id);
                  }}
                  className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 px-6 py-2.5 text-xs font-semibold text-white transition-colors whitespace-nowrap"
                >
                  <Play className="h-4 w-4 fill-current" />
                  <span>{UI_TEXT.continueLearning[language]}</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    setSelectedCourseForDetails(null);
                    setSelectedCourseForCheckout(course);
                  }}
                  className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 px-6 py-2.5 text-xs font-semibold text-slate-950 shadow-lg shadow-cyan-500/20 transition-colors whitespace-nowrap"
                >
                  <ShieldCheck className="h-4 w-4" />
                  <span>{UI_TEXT.enrollNow[language]}</span>
                </button>
              )}
            </div>
          </div>

          {/* Learning Objectives */}
          <div>
            <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
              <Award className="h-4 w-4 text-cyan-400" />
              <span>{UI_TEXT.learningObjectives[language]}</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {course.learningOutcomes.map((item, idx) => (
                <div key={idx} className="flex items-start gap-2.5 rounded-lg border border-slate-800/80 bg-slate-950/40 p-3 text-xs text-slate-300">
                  <CheckCircle className="h-4 w-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span>{item[language]}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Syllabus Chapters Breakdown (~3 Hours) */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Clock className="h-4 w-4 text-cyan-400" />
                <span>{UI_TEXT.syllabusTitle[language]}</span>
              </h3>
              <span className="text-xs font-mono text-slate-400">
                {course.chapters.length} ماژول تخصصی
              </span>
            </div>

            <div className="space-y-3">
              {course.chapters.map((chap, i) => (
                <div 
                  key={chap.id}
                  className="rounded-xl border border-slate-800 bg-slate-950/50 p-4 transition-colors hover:border-slate-700"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-slate-800 text-xs font-mono font-bold text-cyan-400">
                        {i + 1}
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold text-white">
                          {chap.title[language]}
                        </h4>
                        <p className="mt-1 text-xs text-slate-400 leading-relaxed">
                          {chap.summary[language]}
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="font-mono text-xs text-cyan-300 bg-slate-900 px-2 py-0.5 rounded">
                        {formatPlaybackTime(chap.durationSeconds)}
                      </span>
                    </div>
                  </div>

                  {/* Chapter Key Points & Resources */}
                  <div className="mt-3 flex flex-wrap items-center gap-4 text-[11px] text-slate-400 border-t border-slate-800/80 pt-2.5">
                    {chap.resources.map(res => (
                      <span key={res.id} className="flex items-center gap-1 text-slate-400">
                        <FileText className="h-3 w-3 text-slate-500" />
                        <span>{res.title[language]} ({res.fileSize})</span>
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Instructor Dossier */}
          <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-6">
            <h3 className="text-sm font-bold text-slate-200 mb-4">
              {UI_TEXT.instructorDossier[language]}
            </h3>
            <div className="flex items-start gap-4">
              <img
                src={course.instructor.avatar}
                alt={course.instructor.name[language]}
                className="h-14 w-14 rounded-full object-cover ring-2 ring-cyan-500/30 shrink-0"
                referrerPolicy="no-referrer"
              />
              <div>
                <h4 className="text-base font-bold text-white">
                  {course.instructor.name[language]}
                </h4>
                <p className="text-xs text-cyan-400 font-medium">
                  {course.instructor.title[language]}
                </p>
                <p className="mt-2 text-xs text-slate-400 leading-relaxed">
                  {course.instructor.bio[language]}
                </p>
                <div className="mt-2 text-[11px] font-mono text-slate-500">
                  {course.instructor.experienceYears} {UI_TEXT.experienceYears[language]}
                </div>
              </div>
            </div>
          </div>

          {/* Prerequisites */}
          <div>
            <h3 className="text-sm font-bold text-slate-300 mb-2">
              {UI_TEXT.prerequisites[language]}
            </h3>
            <ul className="list-disc list-inside text-xs text-slate-400 space-y-1">
              {course.prerequisites.map((p, idx) => (
                <li key={idx}>{p[language]}</li>
              ))}
            </ul>
          </div>

        </div>

      </div>
    </div>
  );
};
