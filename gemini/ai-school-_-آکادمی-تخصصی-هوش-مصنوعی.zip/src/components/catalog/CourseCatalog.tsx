import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { UI_TEXT } from '../../utils/i18n';
import { CourseCard } from './CourseCard';
import { Search, Sparkles, Filter, Layers, ShieldCheck, CheckCircle2 } from 'lucide-react';

export const CourseCatalog: React.FC = () => {
  const { language, courses, setSelectedCourseForCheckout } = useApp();
  
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Filtered courses
  const filteredCourses = useMemo(() => {
    return courses.filter(course => {
      // Category check
      if (activeCategory !== 'all') {
        if (activeCategory === 'bundle') {
          if (!course.isBundle) return false;
        } else if (course.category !== activeCategory) {
          return false;
        }
      }

      // Search query check
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const titleMatch = course.title[language].toLowerCase().includes(q) || course.title.en.toLowerCase().includes(q);
        const descMatch = course.description[language].toLowerCase().includes(q);
        const instructorMatch = course.instructor.name[language].toLowerCase().includes(q);
        return titleMatch || descMatch || instructorMatch;
      }

      return true;
    });
  }, [courses, activeCategory, searchQuery, language]);

  const bundleCourse = courses.find(c => c.isBundle);

  return (
    <div id="catalog-grid" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 sm:py-14 space-y-10">
      
      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        
        {/* Interactive Segmented Filter Controls */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900/80 border border-slate-800 rounded-xl overflow-x-auto max-w-full">
          {[
            { id: 'all', label: UI_TEXT.filterAll[language] },
            { id: 'llm', label: UI_TEXT.filterLLM[language] },
            { id: 'vision', label: UI_TEXT.filterVision[language] },
            { id: 'systems', label: UI_TEXT.filterSystems[language] },
            { id: 'bundle', label: UI_TEXT.filterBundles[language] },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveCategory(tab.id)}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                activeCategory === tab.id
                  ? 'bg-slate-800 text-cyan-400 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-72">
          <Search className="absolute top-2.5 right-3 h-4 w-4 text-slate-500 rtl:right-3 rtl:left-auto ltr:left-3 ltr:right-auto" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={language === 'fa' ? 'جستجوی سرفصل یا نام استاد...' : 'Search masterclasses...'}
            className="w-full rounded-xl border border-slate-800 bg-slate-900/60 py-2 rtl:pr-9 rtl:pl-3 ltr:pl-9 ltr:pr-3 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
          />
        </div>

      </div>

      {/* Courses Cards Grid */}
      {filteredCourses.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-800 py-16 text-center">
          <p className="text-sm text-slate-400">
            {language === 'fa' ? 'هیچ دوره‌ای با این مشخصات یافت نشد.' : 'No masterclasses found matching your criteria.'}
          </p>
          <button
            onClick={() => { setActiveCategory('all'); setSearchQuery(''); }}
            className="mt-3 text-xs text-cyan-400 hover:underline"
          >
            {language === 'fa' ? 'پاک کردن فیلترها' : 'Reset filters'}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCourses.map(course => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
      )}

      {/* Featured Executive Bundle Showcase Box */}
      {bundleCourse && (
        <div id="bundles-section" className="relative overflow-hidden rounded-2xl border border-slate-800 bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 p-8 sm:p-10 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-8 space-y-4">
              <div className="flex items-center gap-2 text-xs font-mono text-amber-400">
                <Layers className="h-4 w-4" />
                <span>پکیج طلایی مهندسی هوش مصنوعی (۳ مسترکلاس در ۱ پکیج)</span>
              </div>

              <h2 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-white">
                {bundleCourse.title[language]}
              </h2>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl">
                {bundleCourse.description[language]}
              </p>

              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-2">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-cyan-400" />
                  <span>بیش از ۹ ساعت آموزش فشرده</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-cyan-400" />
                  <span>کدهای عملیاتی و ریپازیتوری کامل</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-cyan-400" />
                  <span>گواهی رسمی پایان دوره با اصالت دیجیتال</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-4 flex flex-col items-start lg:items-end justify-center border-t lg:border-t-0 lg:border-l border-slate-800 pt-6 lg:pt-0 lg:pl-8">
              <div className="text-xs text-amber-400 font-semibold mb-1">
                تخفیف ویژه ۴۰ درصدی
              </div>
              <div className="text-2xl sm:text-3xl font-black text-white font-mono tabular-nums mb-4">
                {language === 'fa' ? '۵,۹۰۰,۰۰۰ تومان' : '$99 USD'}
              </div>
              <button
                onClick={() => setSelectedCourseForCheckout(bundleCourse)}
                className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 px-6 py-3 text-xs font-bold text-slate-950 shadow-lg shadow-amber-500/20 transition-all whitespace-nowrap"
              >
                <ShieldCheck className="h-4 w-4" />
                <span>تهیه پکیج کامل با تخفیف</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
