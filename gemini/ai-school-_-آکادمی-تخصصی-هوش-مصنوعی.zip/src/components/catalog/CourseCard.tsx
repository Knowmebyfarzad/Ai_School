import React from 'react';
import { Course } from '../../types';
import { useApp } from '../../context/AppContext';
import { formatDuration, formatPrice, UI_TEXT } from '../../utils/i18n';
import { Play, CheckCircle2, Star, Layers, Shield } from 'lucide-react';

interface CourseCardProps {
  course: Course;
}

export const CourseCard: React.FC<CourseCardProps> = ({ course }) => {
  const { 
    language, 
    currency, 
    currentUser, 
    openClassroom, 
    setSelectedCourseForDetails, 
    setSelectedCourseForCheckout 
  } = useApp();

  const isEnrolled = currentUser.enrolledCourseIds.includes(course.id);
  const userProgress = currentUser.watchProgress[course.id];
  const completedChaptersCount = userProgress?.completedChapterIds?.length || 0;
  const progressPercent = course.chapters.length > 0
    ? Math.round((completedChaptersCount / course.chapters.length) * 100)
    : 0;

  const currentPrice = currency === 'IRR' ? course.priceIRR : course.priceUSD;
  const originalPrice = currency === 'IRR' ? course.originalPriceIRR : course.originalPriceUSD;
  const hasDiscount = originalPrice > currentPrice;

  return (
    <article className="group relative flex flex-col justify-between overflow-hidden rounded-xl border border-slate-800 bg-slate-900/40 hover:border-slate-700/80 transition-all duration-300">
      
      {/* Thumbnail with Overlay */}
      <div>
        <div className="relative aspect-video w-full overflow-hidden bg-slate-950">
          <img
            src={course.thumbnail}
            alt={course.title[language]}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            referrerPolicy="no-referrer"
            onError={(e) => {
              // Graceful CSS fallback container
              const target = e.currentTarget;
              target.style.display = 'none';
              const parent = target.parentElement;
              if (parent) {
                parent.className = 'aspect-video w-full bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 flex items-center justify-center';
              }
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-transparent" />

          {/* Runtime & Bundle Indicator - Clean unboxed text with translucent backing */}
          <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-xs">
            <span className="font-mono text-cyan-300 bg-slate-950/80 px-2 py-0.5 rounded text-[11px] backdrop-blur-sm">
              {formatDuration(course.totalDurationSeconds, language)}
            </span>
            {course.isBundle && (
              <span className="font-mono text-amber-300 bg-slate-950/80 px-2 py-0.5 rounded text-[11px] backdrop-blur-sm flex items-center gap-1">
                <Layers className="h-3 w-3" />
                <span>پکیج طلایی (۳ دوره)</span>
              </span>
            )}
          </div>

          {/* Enrolled Badge */}
          {isEnrolled && (
            <div className="absolute top-2.5 right-3 flex items-center gap-1 bg-emerald-500/90 text-slate-950 px-2 py-0.5 rounded text-[11px] font-semibold shadow-md">
              <CheckCircle2 className="h-3.5 w-3.5" />
              <span>{UI_TEXT.enrolled[language]}</span>
            </div>
          )}
        </div>

        {/* Card Body */}
        <div className="p-5">
          
          {/* Zero-Pill Unboxed Metadata Header */}
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
            <span className="capitalize">{course.category}</span>
            <span aria-hidden="true">·</span>
            <span>{course.chapters.length} {UI_TEXT.modulesCount[language]}</span>
            <span aria-hidden="true">·</span>
            <span className="flex items-center gap-0.5 text-amber-400 font-mono">
              <Star className="h-3 w-3 fill-current" />
              <span>{course.rating}</span>
              <span className="text-slate-500 text-[10px]">({course.reviewsCount})</span>
            </span>
          </div>

          {/* Title */}
          <h3 className="text-base font-bold text-white line-clamp-2 leading-snug group-hover:text-cyan-400 transition-colors">
            {course.title[language]}
          </h3>

          {/* Subtitle / Description */}
          <p className="mt-2 text-xs text-slate-400 line-clamp-2 leading-relaxed">
            {course.description[language]}
          </p>

          {/* Instructor line */}
          <div className="mt-4 flex items-center gap-2 text-xs text-slate-300">
            <img
              src={course.instructor.avatar}
              alt={course.instructor.name[language]}
              className="h-5 w-5 rounded-full object-cover"
              referrerPolicy="no-referrer"
            />
            <span className="truncate">{course.instructor.name[language]}</span>
          </div>

          {/* Progress bar if enrolled */}
          {isEnrolled && (
            <div className="mt-4 border-t border-slate-800/80 pt-3">
              <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                <span>{UI_TEXT.progress[language]}</span>
                <span className="font-mono text-cyan-400">{progressPercent}٪</span>
              </div>
              <div className="h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full transition-all duration-500"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Card Footer: Pricing & Action Controls */}
      <div className="border-t border-slate-800/80 p-5 pt-4 bg-slate-950/40">
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex flex-col">
            <div className="flex items-baseline gap-2">
              <span className="text-lg font-bold text-white font-mono tabular-nums">
                {formatPrice(currentPrice, currency, language)}
              </span>
              {hasDiscount && (
                <span className="text-xs text-slate-500 line-through font-mono tabular-nums">
                  {formatPrice(originalPrice, currency, language)}
                </span>
              )}
            </div>
            <span className="text-[11px] text-slate-400">
              پرداخت یکباره · دسترسی همیشگی
            </span>
          </div>

          <button
            onClick={() => setSelectedCourseForDetails(course)}
            className="text-xs text-slate-300 hover:text-white underline underline-offset-4 decoration-slate-600 transition-colors whitespace-nowrap"
          >
            {UI_TEXT.viewSyllabus[language]}
          </button>
        </div>

        {/* Primary Action Button */}
        {isEnrolled ? (
          <button
            onClick={() => openClassroom(course.id)}
            className="w-full flex items-center justify-center gap-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 px-4 py-2 text-xs font-semibold text-white shadow-sm transition-colors whitespace-nowrap"
          >
            <Play className="h-3.5 w-3.5 fill-current" />
            <span>{UI_TEXT.continueLearning[language]}</span>
          </button>
        ) : (
          <button
            onClick={() => setSelectedCourseForCheckout(course)}
            className="w-full flex items-center justify-center gap-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 px-4 py-2 text-xs font-semibold text-slate-950 shadow-md shadow-cyan-500/10 transition-colors whitespace-nowrap"
          >
            <Shield className="h-3.5 w-3.5" />
            <span>{UI_TEXT.enrollNow[language]}</span>
          </button>
        )}
      </div>

    </article>
  );
};
