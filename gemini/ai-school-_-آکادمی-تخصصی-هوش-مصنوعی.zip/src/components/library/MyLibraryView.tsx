import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatDuration, UI_TEXT } from '../../utils/i18n';
import { 
  BookOpen, 
  Play, 
  Award, 
  Clock, 
  CheckCircle2, 
  Layers, 
  Download, 
  Share2, 
  X,
  ShieldCheck
} from 'lucide-react';
import { Course } from '../../types';

export const MyLibraryView: React.FC = () => {
  const { 
    language, 
    courses, 
    currentUser, 
    openClassroom, 
    setCurrentView 
  } = useApp();

  const [activeCertificateCourse, setActiveCertificateCourse] = useState<Course | null>(null);

  // Filter courses that user is enrolled in
  const enrolledCourses = courses.filter(c => currentUser.enrolledCourseIds.includes(c.id));

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      
      {/* Header */}
      <div className="border-b border-slate-800 pb-6">
        <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono mb-2">
          <BookOpen className="h-4 w-4" />
          <span>حساب کاربری: {currentUser.email}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
          {UI_TEXT.myLibraryTitle[language]}
        </h1>
        <p className="mt-2 text-sm text-slate-400 max-w-2xl">
          {UI_TEXT.myLibrarySubtitle[language]}
        </p>
      </div>

      {/* Enrolled Courses Grid or Empty State */}
      {enrolledCourses.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-800 bg-slate-900/30 p-12 text-center">
          <BookOpen className="mx-auto h-12 w-12 text-slate-600 mb-4" />
          <h3 className="text-base font-bold text-white mb-2">
            {UI_TEXT.emptyLibrary[language]}
          </h3>
          <p className="text-xs text-slate-400 mb-6 max-w-sm mx-auto">
            دوره‌های تخصصی ۳ ساعته هوش مصنوعی را با یکبار پرداخت تهیه کرده و در هر زمان به محتوا و کدهای عملیاتی دسترسی داشته باشید.
          </p>
          <button
            onClick={() => setCurrentView('catalog')}
            className="rounded-xl bg-cyan-500 hover:bg-cyan-400 px-5 py-2.5 text-xs font-semibold text-slate-950 transition-colors"
          >
            {UI_TEXT.emptyLibraryCta[language]}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {enrolledCourses.map(course => {
            const progress = currentUser.watchProgress[course.id];
            const completedCount = progress?.completedChapterIds?.length || 0;
            const totalChapters = course.chapters.length;
            const percent = totalChapters > 0 ? Math.round((completedCount / totalChapters) * 100) : 0;
            const isCompleted = percent === 100 || progress?.certificateIssued;

            const lastChapter = course.chapters.find(ch => ch.id === progress?.lastChapterId) || course.chapters[0];

            return (
              <div 
                key={course.id}
                className="group flex flex-col justify-between rounded-xl border border-slate-800 bg-slate-900/50 overflow-hidden hover:border-slate-700 transition-all"
              >
                <div>
                  {/* Thumbnail with overlay */}
                  <div className="relative aspect-video w-full overflow-hidden bg-slate-950">
                    <img
                      src={course.thumbnail}
                      alt={course.title[language]}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
                    
                    <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-xs text-white">
                      <span className="font-mono text-cyan-300 text-[11px] bg-slate-950/80 px-2 py-0.5 rounded">
                        {formatDuration(course.totalDurationSeconds, language)}
                      </span>
                      {isCompleted && (
                        <span className="flex items-center gap-1 bg-emerald-500/90 text-slate-950 font-bold px-2 py-0.5 rounded text-[11px]">
                          <CheckCircle2 className="h-3 w-3" />
                          <span>تکمیل شده</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Body */}
                  <div className="p-5">
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 mb-2">
                      <span className="uppercase font-mono">{course.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{completedCount} از {totalChapters} ماژول</span>
                    </div>

                    <h3 className="text-sm font-bold text-white line-clamp-2 leading-snug">
                      {course.title[language]}
                    </h3>

                    {/* Progress Bar */}
                    <div className="mt-4 space-y-1.5">
                      <div className="flex justify-between text-[11px] text-slate-400">
                        <span>{UI_TEXT.progress[language]}</span>
                        <span className="font-mono text-cyan-400 font-semibold">{percent}٪</span>
                      </div>
                      <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-cyan-500 to-emerald-500 rounded-full transition-all duration-300"
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>

                    {/* Last chapter status */}
                    <div className="mt-4 rounded-lg border border-slate-800 bg-slate-950/60 p-2.5 text-xs text-slate-300">
                      <div className="text-[10px] text-slate-500 mb-0.5">آخرین وضعیت تماشا:</div>
                      <div className="truncate font-medium text-slate-200">
                        {lastChapter?.title[language]}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer Buttons */}
                <div className="p-5 pt-0 space-y-2">
                  <button
                    onClick={() => openClassroom(course.id, progress?.lastChapterId)}
                    className="w-full flex items-center justify-center gap-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 py-2.5 text-xs font-semibold text-slate-950 shadow-md shadow-cyan-500/10 transition-colors whitespace-nowrap"
                  >
                    <Play className="h-3.5 w-3.5 fill-current" />
                    <span>{UI_TEXT.continueLearning[language]}</span>
                  </button>

                  {/* Certificate button */}
                  {isCompleted && (
                    <button
                      onClick={() => setActiveCertificateCourse(course)}
                      className="w-full flex items-center justify-center gap-2 rounded-lg border border-amber-500/40 bg-amber-950/20 hover:bg-amber-900/30 py-2 text-xs font-medium text-amber-300 transition-colors whitespace-nowrap"
                    >
                      <Award className="h-3.5 w-3.5 text-amber-400" />
                      <span>{UI_TEXT.downloadCertificate[language]}</span>
                    </button>
                  )}
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* Official Certificate Modal */}
      {activeCertificateCourse && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="relative w-full max-w-2xl rounded-2xl border-2 border-amber-500/40 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 p-8 shadow-2xl text-center space-y-6">
            <button
              onClick={() => setActiveCertificateCourse(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-amber-500/10 text-amber-400 ring-2 ring-amber-500/30">
              <Award className="h-8 w-8" />
            </div>

            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-amber-400">
                گواهی رسمی پایان دوره تخصصی
              </span>
              <h2 className="text-2xl font-black text-white mt-2">
                ACADEMY OF ARTIFICIAL INTELLIGENCE
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                AI SCHOOL VERIFIED CERTIFICATE OF ACCOMPLISHMENT
              </p>
            </div>

            <div className="border-t border-b border-slate-800 py-6 space-y-3">
              <p className="text-xs text-slate-400">بدین‌وسیله گواهی می‌شود که دانش‌پژوه گرامی:</p>
              <h3 className="text-xl font-bold text-cyan-400">{currentUser.name}</h3>
              <p className="text-xs text-slate-300 max-w-lg mx-auto leading-relaxed">
                مسترکلاس پیشرفته «<strong>{activeCertificateCourse.title[language]}</strong>» را با موفقیت و بررسی کلیه پروژه‌های عملی به پایان رسانده است.
              </p>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400 pt-2 font-mono">
              <div className="text-right">
                <div>مدرس: {activeCertificateCourse.instructor.name[language]}</div>
                <div className="text-[10px] text-slate-500">مهر دیجیتال آکادمی هوش مصنوعی</div>
              </div>
              <div className="text-left">
                <div>شناسه مدرک: AIS-{Math.floor(100000 + Math.random() * 900000)}</div>
                <div className="text-[10px] text-emerald-400">وضعیت: معتبر و قابل استعلام آنلاین</div>
              </div>
            </div>

            <div className="pt-4 flex items-center justify-center gap-3">
              <button
                onClick={() => window.print()}
                className="flex items-center gap-2 rounded-xl bg-amber-500 hover:bg-amber-400 px-5 py-2.5 text-xs font-bold text-slate-950 transition-colors"
              >
                <Download className="h-4 w-4" />
                <span>چاپ و ذخیره فایل PDF</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
