import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { formatPlaybackTime, formatDuration, UI_TEXT } from '../../utils/i18n';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Minimize, 
  RotateCcw, 
  RotateCw, 
  ShieldAlert, 
  ShieldCheck, 
  Key, 
  CheckCircle, 
  FileText, 
  Download, 
  ArrowRight, 
  ArrowLeft,
  Info,
  Tv,
  Lock
} from 'lucide-react';

export const SecureVideoPlayer: React.FC = () => {
  const { 
    language, 
    currentUser, 
    activeCourse, 
    activeChapterId, 
    setActiveChapterId, 
    setCurrentView,
    updateWatchProgress 
  } = useApp();

  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Active chapter
  const currentChapter = activeCourse?.chapters.find(c => c.id === activeChapterId) || activeCourse?.chapters[0];
  const userProgress = activeCourse ? currentUser.watchProgress[activeCourse.id] : undefined;
  const isCurrentChapterCompleted = currentChapter && userProgress?.completedChapterIds?.includes(currentChapter.id);

  // Playback states
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(userProgress?.lastPositionSeconds || 0);
  const [duration, setDuration] = useState(currentChapter?.durationSeconds || 1800);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Dynamic Floating Watermark State
  const [watermarkPos, setWatermarkPos] = useState({ top: '25%', left: '30%' });
  const [liveTimestamp, setLiveTimestamp] = useState(new Date().toISOString().replace('T', ' ').substring(0, 19));
  const [sessionToken, setSessionToken] = useState(() => `tk_${Math.random().toString(36).substring(2, 12)}`);
  const [tokenTimeLeft, setTokenTimeLeft] = useState(885); // 14 mins 45s

  // Security warning & DRM Modal
  const [securityAlert, setSecurityAlert] = useState<string | null>(null);
  const [showDrmModal, setShowDrmModal] = useState(false);

  // Update floating watermark position every 9 seconds to random coordinates
  useEffect(() => {
    const watermarkInterval = setInterval(() => {
      // Calculate random coordinates ensuring watermark stays inside player safe area
      const randomTop = Math.floor(15 + Math.random() * 65);
      const randomLeft = Math.floor(10 + Math.random() * 70);
      setWatermarkPos({ top: `${randomTop}%`, left: `${randomLeft}%` });
      setLiveTimestamp(new Date().toISOString().replace('T', ' ').substring(0, 19));
    }, 9000);

    return () => clearInterval(watermarkInterval);
  }, []);

  // Token rotation countdown
  useEffect(() => {
    const tokenInterval = setInterval(() => {
      setTokenTimeLeft(prev => {
        if (prev <= 1) {
          // Token refreshed automatically
          setSessionToken(`tk_${Math.random().toString(36).substring(2, 12)}`);
          return 900; // Reset to 15m
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(tokenInterval);
  }, []);

  // Sync video time and progress
  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const time = videoRef.current.currentTime;
      setCurrentTime(time);
      if (activeCourse && currentChapter) {
        // Save progress periodically
        updateWatchProgress(activeCourse.id, currentChapter.id, time);
      }
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration || currentChapter?.durationSeconds || 1800);
      if (userProgress && userProgress.lastPositionSeconds > 0) {
        videoRef.current.currentTime = userProgress.lastPositionSeconds;
      }
    }
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
      }
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const target = parseFloat(e.target.value);
    setCurrentTime(target);
    if (videoRef.current) {
      videoRef.current.currentTime = target;
    }
  };

  const skipSeconds = (seconds: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = Math.max(0, Math.min(duration, videoRef.current.currentTime + seconds));
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (videoRef.current) {
      videoRef.current.volume = val;
      setIsMuted(val === 0);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      if (isMuted) {
        videoRef.current.muted = false;
        videoRef.current.volume = volume || 0.8;
        setIsMuted(false);
      } else {
        videoRef.current.muted = true;
        setIsMuted(true);
      }
    }
  };

  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  const togglePiP = async () => {
    if (videoRef.current && document.pictureInPictureEnabled) {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else {
        await videoRef.current.requestPictureInPicture();
      }
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is typing in an input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) return;

      if (e.code === 'Space') {
        e.preventDefault();
        togglePlay();
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        skipSeconds(language === 'fa' ? -5 : 5);
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        skipSeconds(language === 'fa' ? 5 : -5);
      } else if (e.code === 'KeyM') {
        e.preventDefault();
        toggleMute();
      } else if (e.code === 'KeyF') {
        e.preventDefault();
        toggleFullscreen();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isMuted, language, duration]);

  // Anti-tamper: Block context menu on player
  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    setSecurityAlert(
      language === 'fa'
        ? 'دانلود مستقیم ویدیو به دلایل کپی‌رایت مسدود است. دسترسی به استریم فقط از طریق پلیر مجاز می‌باشد.'
        : 'Direct video extraction is restricted under DRM copyright policy. Stream access is bound to your session.'
    );
    setTimeout(() => setSecurityAlert(null), 4000);
  };

  if (!activeCourse || !currentChapter) {
    return (
      <div className="py-20 text-center">
        <p className="text-slate-400">دوره‌ای انتخاب نشده است.</p>
        <button
          onClick={() => setCurrentView('catalog')}
          className="mt-4 rounded-lg bg-cyan-500 px-4 py-2 text-xs font-semibold text-slate-950"
        >
          بازگشت به کاتالوگ
        </button>
      </div>
    );
  }

  const completedCount = userProgress?.completedChapterIds?.length || 0;
  const progressPercent = Math.round((completedCount / activeCourse.chapters.length) * 100);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <button
            onClick={() => setCurrentView('library')}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-cyan-400 transition-colors mb-1.5"
          >
            {language === 'fa' ? <ArrowRight className="h-3.5 w-3.5" /> : <ArrowLeft className="h-3.5 w-3.5" />}
            <span>بازگشت به کتابخانه من</span>
          </button>
          <h1 className="text-lg sm:text-xl font-bold text-white">
            {activeCourse.title[language]}
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            {currentChapter.title[language]}
          </p>
        </div>

        {/* Security & Token Health Badge */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-900/80 px-3 py-1.5 text-xs">
            <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
            <div className="flex flex-col">
              <span className="text-[11px] font-mono text-slate-300">
                توکن امن: <span className="text-cyan-400">{sessionToken}</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                چرخش توکن در: {Math.floor(tokenTimeLeft / 60)}:{(tokenTimeLeft % 60).toString().padStart(2, '0')}
              </span>
            </div>
          </div>

          <button
            onClick={() => setShowDrmModal(true)}
            className="rounded-lg border border-slate-800 bg-slate-900 p-2 text-slate-400 hover:text-white transition-colors"
            title={UI_TEXT.drmArchitectureInfo[language]}
          >
            <Info className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Main Grid: Video Player (Left/Top) + Chapter Sidebar (Right/Bottom) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left 8 Cols: Hardened Video Player & Tools */}
        <div className="lg:col-span-8 space-y-4">
          
          {/* Video Container Frame */}
          <div 
            ref={containerRef}
            onContextMenu={handleContextMenu}
            onMouseEnter={() => setShowControls(true)}
            onMouseMove={() => {
              setShowControls(true);
              if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
              controlsTimeoutRef.current = setTimeout(() => {
                if (isPlaying) setShowControls(false);
              }, 3500);
            }}
            className="unselectable relative aspect-video w-full overflow-hidden rounded-2xl bg-black shadow-2xl border border-slate-800 group"
          >
            {/* HTML5 Native Video Tag */}
            <video
              ref={videoRef}
              src={currentChapter.videoUrl}
              onTimeUpdate={handleTimeUpdate}
              onLoadedMetadata={handleLoadedMetadata}
              onClick={togglePlay}
              playsInline
              className="h-full w-full object-cover cursor-pointer"
            />

            {/* DYNAMIC FLOATING WATERMARK (Deters Leaks and Screen Recording) */}
            <div 
              className="pointer-events-none absolute z-30 transition-all duration-1000 ease-out flex flex-col items-start select-none"
              style={{
                top: watermarkPos.top,
                left: watermarkPos.left,
                transform: 'translate(-50%, -50%)',
              }}
            >
              <div className="bg-black/35 backdrop-blur-[2px] rounded px-2.5 py-1 text-[11px] font-mono text-white/50 tracking-wider shadow-sm border border-white/10">
                <div className="flex items-center gap-1.5 font-bold">
                  <span>{currentUser.email}</span>
                </div>
                <div className="text-[9px] text-white/40 flex items-center gap-2 mt-0.5">
                  <span>{sessionToken}</span>
                  <span>·</span>
                  <span>{liveTimestamp}</span>
                </div>
              </div>
            </div>

            {/* Secondary subtle corner watermark */}
            <div className="pointer-events-none absolute bottom-16 right-4 z-20 text-[10px] font-mono text-white/20 select-none">
              AI School Security Shield · ID: {currentUser.id}
            </div>

            {/* Security Alert Toast */}
            {securityAlert && (
              <div className="absolute top-4 left-4 right-4 z-40 flex items-center gap-2 rounded-xl border border-amber-500/50 bg-slate-950/90 p-3 text-xs text-amber-300 backdrop-blur-md shadow-2xl animate-fade-in">
                <ShieldAlert className="h-4 w-4 shrink-0 text-amber-400" />
                <span>{securityAlert}</span>
              </div>
            )}

            {/* Center Big Play Button when paused */}
            {!isPlaying && (
              <button
                onClick={togglePlay}
                className="absolute inset-0 z-20 flex items-center justify-center bg-black/30 backdrop-blur-[1px]"
              >
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-cyan-500 text-slate-950 shadow-2xl transition-transform hover:scale-110">
                  <Play className="h-8 w-8 fill-current translate-x-0.5" />
                </div>
              </button>
            )}

            {/* Custom Overlay Control Bar */}
            <div 
              className={`absolute bottom-0 left-0 right-0 z-30 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent p-4 transition-opacity duration-300 ${
                showControls || !isPlaying ? 'opacity-100' : 'opacity-0 pointer-events-none'
              }`}
            >
              {/* Scrubber Progress Slider */}
              <div className="relative mb-2.5 flex items-center">
                <input
                  type="range"
                  min="0"
                  max={duration || 100}
                  step="0.1"
                  value={currentTime}
                  onChange={handleSeek}
                  className="w-full h-1.5 bg-slate-700/80 rounded-lg appearance-none cursor-pointer accent-cyan-400 hover:h-2 transition-all"
                />
              </div>

              {/* Action Buttons Row */}
              <div className="flex items-center justify-between text-xs text-white">
                
                {/* Left controls: Play, Skip, Time */}
                <div className="flex items-center gap-3">
                  <button
                    onClick={togglePlay}
                    className="p-1 hover:text-cyan-400 transition-colors"
                  >
                    {isPlaying ? <Pause className="h-5 w-5 fill-current" /> : <Play className="h-5 w-5 fill-current" />}
                  </button>

                  <button
                    onClick={() => skipSeconds(-5)}
                    className="p-1 hover:text-cyan-400 transition-colors"
                    title="-5s"
                  >
                    <RotateCcw className="h-4 w-4" />
                  </button>

                  <button
                    onClick={() => skipSeconds(5)}
                    className="p-1 hover:text-cyan-400 transition-colors"
                    title="+5s"
                  >
                    <RotateCw className="h-4 w-4" />
                  </button>

                  {/* Volume Control */}
                  <div className="flex items-center gap-1.5 ml-1">
                    <button onClick={toggleMute} className="hover:text-cyan-400">
                      {isMuted || volume === 0 ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                    </button>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={isMuted ? 0 : volume}
                      onChange={handleVolumeChange}
                      className="w-16 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-400 hidden sm:block"
                    />
                  </div>

                  {/* Playback time */}
                  <div className="font-mono text-xs text-slate-300 ml-2 tabular-nums">
                    <span>{formatPlaybackTime(currentTime)}</span>
                    <span className="text-slate-500 mx-1">/</span>
                    <span className="text-slate-400">{formatPlaybackTime(duration)}</span>
                  </div>
                </div>

                {/* Right controls: Speed, PiP, Fullscreen */}
                <div className="flex items-center gap-2.5">
                  {/* Playback Speed Selector */}
                  <div className="flex items-center rounded-lg border border-slate-700 bg-slate-900/70 p-0.5 text-[11px] font-mono">
                    {[0.75, 1, 1.25, 1.5, 2].map((s) => (
                      <button
                        key={s}
                        onClick={() => handleSpeedChange(s)}
                        className={`px-1.5 py-0.5 rounded transition-colors ${
                          playbackSpeed === s ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {s}x
                      </button>
                    ))}
                  </div>

                  {/* PiP */}
                  <button
                    onClick={togglePiP}
                    className="p-1 hover:text-cyan-400 transition-colors hidden sm:block"
                    title="Picture in Picture"
                  >
                    <Tv className="h-4 w-4" />
                  </button>

                  {/* Fullscreen */}
                  <button
                    onClick={toggleFullscreen}
                    className="p-1 hover:text-cyan-400 transition-colors"
                  >
                    {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
                  </button>
                </div>

              </div>
            </div>

          </div>

          {/* Module Action Bar & Chapter Completion */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-4">
            <div>
              <h3 className="text-sm font-bold text-white">
                {currentChapter.title[language]}
              </h3>
              <p className="mt-1 text-xs text-slate-400">
                {currentChapter.summary[language]}
              </p>
            </div>

            <button
              onClick={() => {
                updateWatchProgress(activeCourse.id, currentChapter.id, currentTime, true);
              }}
              className={`flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold transition-colors shrink-0 ${
                isCurrentChapterCompleted
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : 'bg-slate-800 text-slate-200 hover:bg-slate-700 border border-slate-700'
              }`}
            >
              <CheckCircle className="h-4 w-4" />
              <span>
                {isCurrentChapterCompleted ? UI_TEXT.completed[language] : UI_TEXT.markComplete[language]}
              </span>
            </button>
          </div>

          {/* Downloadable Resources & Exercise Code */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-4">
            <h4 className="text-xs font-bold text-slate-200 mb-3 flex items-center gap-1.5">
              <Download className="h-3.5 w-3.5 text-cyan-400" />
              <span>{UI_TEXT.downloadResources[language]}</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {currentChapter.resources.map(res => (
                <div 
                  key={res.id} 
                  className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950 p-2.5 text-xs"
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileText className="h-4 w-4 text-cyan-400 shrink-0" />
                    <span className="text-slate-200 truncate">{res.title[language]}</span>
                  </div>
                  <span className="font-mono text-[11px] text-slate-500 shrink-0 ml-2">
                    {res.fileSize}
                  </span>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right 4 Cols: Full Chapter Navigation Playlist */}
        <div className="lg:col-span-4 rounded-xl border border-slate-800 bg-slate-900/60 p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white">
                {UI_TEXT.chaptersList[language]}
              </h3>
              <span className="text-[11px] text-slate-400">
                مجموع: {formatDuration(activeCourse.totalDurationSeconds, language)}
              </span>
            </div>
            <span className="font-mono text-xs font-bold text-cyan-400">
              {progressPercent}٪
            </span>
          </div>

          {/* Progress bar */}
          <div className="h-1.5 w-full rounded-full bg-slate-800 overflow-hidden -mt-2">
            <div 
              className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* Chapters List */}
          <div className="space-y-2 max-h-[580px] overflow-y-auto pr-1">
            {activeCourse.chapters.map((chap, idx) => {
              const isActive = chap.id === currentChapter.id;
              const isDone = userProgress?.completedChapterIds?.includes(chap.id);

              return (
                <button
                  key={chap.id}
                  onClick={() => setActiveChapterId(chap.id)}
                  className={`w-full flex items-start gap-3 rounded-xl border p-3 text-right transition-all ${
                    isActive
                      ? 'border-cyan-500/80 bg-cyan-950/20 ring-1 ring-cyan-500/30'
                      : 'border-slate-800 bg-slate-950/40 hover:border-slate-700'
                  }`}
                >
                  <div className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-md text-xs font-mono font-bold ${
                    isDone 
                      ? 'bg-emerald-500/20 text-emerald-400' 
                      : isActive 
                        ? 'bg-cyan-500 text-slate-950' 
                        : 'bg-slate-800 text-slate-400'
                  }`}>
                    {isDone ? '✓' : idx + 1}
                  </div>

                  <div className="flex-1 min-w-0">
                    <h5 className={`text-xs font-semibold line-clamp-1 ${isActive ? 'text-cyan-400' : 'text-slate-200'}`}>
                      {chap.title[language]}
                    </h5>
                    <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500">
                      <span>{chap.resources.length} پیوست</span>
                      <span className="font-mono tabular-nums text-slate-400">
                        {formatPlaybackTime(chap.durationSeconds)}
                      </span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

        </div>

      </div>

      {/* DRM & Security Architecture Drawer Modal */}
      {showDrmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-2xl border border-slate-800 bg-slate-900 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <Lock className="h-4 w-4 text-cyan-400" />
                <span>مشخصات فنی و معماری پلیر امن (DRM Spec)</span>
              </div>
              <button onClick={() => setShowDrmModal(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <div className="text-xs text-slate-300 space-y-3 leading-relaxed">
              <p>
                <strong>۱. استریم چند تکه محافظت‌شده (HLS / DASH):</strong> ویدئوهای ۳ ساعته به سگمنت‌های رمزنگاری شده ۲ ثانیه‌ای با کلیدهای چرخشی AES-128 تقسیم می‌شوند.
              </p>
              <p>
                <strong>۲. توکن‌های کوتاه‌عمر (Short-Lived Tokens):</strong> دسترسی به مانیفست استریم توسط Nginx Secure Link و کوکی‌های امضاشده فقط برای ۱۵ دقیقه معتبر است.
              </p>
              <p>
                <strong>۳. واترمارک ردیابی پویا (Dynamic Forensic Watermark):</strong> شناسه کاربری و برچسب زمانی بلادرنگ در موقعیت‌های تصادفی پلیر شناور بوده و امکان شناسایی نشت‌دهنده در صورت ضبط نمایشگر را فراهم می‌کند.
              </p>
              <p>
                <strong>۴. استقرار سازمانی Widevine / FairPlay:</strong> در محیط پروداکشن، ماژول‌های CDM مرورگر کلیدهای دیکریپشن را مستقیماً در بافر سخت‌افزاری دریافت کرده و از بازرسی شبکه محافظت می‌کنند.
              </p>
            </div>

            <button
              onClick={() => setShowDrmModal(false)}
              className="w-full rounded-xl bg-slate-800 py-2.5 text-xs font-semibold text-white hover:bg-slate-700"
            >
              متوجه شدم
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
