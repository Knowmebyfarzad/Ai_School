/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { HeroBanner } from './components/catalog/HeroBanner';
import { CourseCatalog } from './components/catalog/CourseCatalog';
import { CourseDetailsModal } from './components/catalog/CourseDetailsModal';
import { CheckoutModal } from './components/checkout/CheckoutModal';
import { SecureVideoPlayer } from './components/player/SecureVideoPlayer';
import { MyLibraryView } from './components/library/MyLibraryView';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { InvoiceModal } from './components/invoice/InvoiceModal';
import { Footer } from './components/layout/Footer';

const AppContent: React.FC = () => {
  const { currentView } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 selection:bg-cyan-500 selection:text-slate-950">
      <Navbar />

      <main className="flex-1">
        {currentView === 'catalog' && (
          <>
            <HeroBanner />
            <CourseCatalog />
          </>
        )}

        {currentView === 'library' && <MyLibraryView />}

        {currentView === 'classroom' && <SecureVideoPlayer />}

        {currentView === 'admin' && <AdminDashboard />}
      </main>

      {/* Global Modals */}
      <CourseDetailsModal />
      <CheckoutModal />
      <InvoiceModal />

      <Footer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
