import { Course, Order, User } from '../types';

// High-reliability video clips for browser playback testing
const VIDEO_STREAM_1 = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';
const VIDEO_STREAM_2 = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4';
const VIDEO_STREAM_3 = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4';
const VIDEO_STREAM_4 = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4';

export const INITIAL_COURSES: Course[] = [
  {
    id: 'course-llm-agents',
    slug: 'advanced-llms-agentic-workflows',
    title: {
      fa: 'مستربکلاس مدل‌های زبانی بزرگ و سیستم‌های عامل‌محور (LLMs & Multi-Agent Systems)',
      en: 'Mastering LLMs & Autonomous Multi-Agent Architectures'
    },
    subtitle: {
      fa: 'دوره جامع ۳ ساعته: از معماری ترنسفورمرها و پرامپتینگ پیشرفته تا فریم‌ورک‌های LangGraph و ابزارمحوری',
      en: 'Intensive 3-hour deep dive: from Transformer mechanics to LangGraph orchestration and production tool calling'
    },
    description: {
      fa: 'در این مسترکلاس فشرده و تخصصی ۳ ساعته، عمیق‌ترین مباحث معماری مدل‌های زبانی مدرن را بررسی می‌کنیم. یاد می‌گیرید چگونه پایپ‌لاین‌های چندعامله (Multi-Agent)، حافظه‌های بلندمدت برداری و سیستم‌های تصمیم‌گیری بلادرنگ را بدون سرریز توکن طراحی و در محیط عملیاتی مستقر کنید.',
      en: 'In this intensive 3-hour masterclass, master modern LLM architectures, context engineering, autonomous reasoning loops, LangGraph state machines, and real-time tool calling with production token governance.'
    },
    category: 'llm',
    level: 'intermediate',
    thumbnail: '/src/assets/images/ai_course_llm_agents_1792412069566.jpg',
    previewVideoUrl: VIDEO_STREAM_4,
    instructor: {
      id: 'inst-1',
      name: { fa: 'دکتر علیرضا رستگار', en: 'Dr. Alireza Rastegar' },
      title: { fa: 'پژوهشگر ارشد هوش مصنوعی و مهندس یادگیری عمیق', en: 'Principal AI Research Engineer' },
      bio: {
        fa: 'فارغ‌التحصیل هوش مصنوعی با بیش از ۱۲ سال تجربه طراحی مدل‌های تجاری و استقرار سیستم‌های تولیدی هوش مصنوعی مقیاس‌پذیر.',
        en: 'Over 12 years of enterprise ML infrastructure engineering, specializing in generative transformers and autonomous agent loops.'
      },
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      experienceYears: 12
    },
    totalDurationSeconds: 11400, // 3 hours 10 mins
    priceIRR: 2850000, // 2,850,000 Tomans
    originalPriceIRR: 4200000,
    priceUSD: 49,
    originalPriceUSD: 79,
    rating: 4.94,
    reviewsCount: 348,
    updatedAt: '2026-09-15',
    enrolledUserIds: ['user-farzad'],
    learningOutcomes: [
      { fa: 'درک ریاضی و مهندسی Attention Mechanism و RoPE embeddings', en: 'Mathematical mastery of Multi-Head Attention and RoPE embeddings' },
      { fa: 'طراحی عامل‌های تصمیم‌گیرنده با فریم‌ورک LangGraph و CrewAI', en: 'Building deterministic agent state graphs with LangGraph and CrewAI' },
      { fa: 'پیاده‌سازی حافظه بلندمدت با پایگاه‌های داده برداری PgVector و Pinecone', en: 'Architecting hierarchical long-term vector memory with PgVector' },
      { fa: 'تکنیک‌های بهینه‌سازی هزینه و کش استریم توکن در مقیاس صنعتی', en: 'Token stream caching and enterprise inference cost optimization' }
    ],
    prerequisites: [
      { fa: 'آشنایی با زبان پایتون و اصول یادگیری ماشین', en: 'Familiarity with Python and foundational Machine Learning' },
      { fa: 'آشنایی با APIهای REST و محیط‌های لینوکس', en: 'Basic comfort with RESTful APIs and container environments' }
    ],
    chapters: [
      {
        id: 'chap-llm-1',
        title: { fa: '۱. کالبدشکافی ترنسفورمرها و مکانیک توجه (Attention Mechanics)', en: '1. Transformer Dissection & Attention Mechanics' },
        durationSeconds: 1560, // 26 min
        videoUrl: VIDEO_STREAM_1,
        summary: {
          fa: 'بررسی لایه‌های ترنسفورمر، ماتریس‌های Query, Key, Value، چرخش موقعیتی و جریان گرادیان در پنجره‌های زمینه بزرگ.',
          en: 'In-depth analysis of QKV projection, rotary positional embeddings (RoPE), and gradient flow across large context windows.'
        },
        keyPoints: [
          { fa: 'ریاضیات ماتریکس‌های QKV در عمل', en: 'QKV projection algebra in practice' },
          { fa: 'حل مشکل محو شدگی توجه در متن‌های طولانی', en: 'Attention decay resolution in 128k+ contexts' }
        ],
        resources: [
          { id: 'res-1', title: { fa: 'اسلایدهای معماری ترنسفورمر', en: 'Transformer Architecture Slides' }, fileType: 'pdf', fileSize: '4.8 MB' },
          { id: 'res-2', title: { fa: 'نوتبوک کد پایتورچ توجه اختصاصی', en: 'Custom Flash-Attention PyTorch Notebook' }, fileType: 'ipynb', fileSize: '1.2 MB' }
        ]
      },
      {
        id: 'chap-llm-2',
        title: { fa: '۲. مهندسی پیشرفته پرامپت و استدلال زنجیره‌ای (CoT & ToT)', en: '2. Advanced Context Engineering & Chain of Thought' },
        durationSeconds: 1680, // 28 min
        videoUrl: VIDEO_STREAM_2,
        summary: {
          fa: 'ساختاربندی استدلال مدل با متدهای Tree of Thoughts، کاهش خطا و تضمین خروجی‌های ساخت‌یافته JSON/Pydantic.',
          en: 'Structured reasoning frameworks, Tree of Thoughts, hallucination suppression, and strict JSON schema guarantees.'
        },
        keyPoints: [
          { fa: 'تضمین ساختار داده Pydantic بدون شکست فیلد', en: 'Deterministic Pydantic validation without syntax collapse' },
          { fa: 'کاهش توهم مدل در تحلیل‌های حساس سازمانی', en: 'Systematic hallucination dampening techniques' }
        ],
        resources: [
          { id: 'res-3', title: { fa: 'کتابچه تمپلیت‌های پرامپت مهندسی', en: 'Enterprise Prompt Cookbook' }, fileType: 'json', fileSize: '650 KB' }
        ]
      },
      {
        id: 'chap-llm-3',
        title: { fa: '۳. طراحی پایپ‌لاین پیشرفته RAG چندمرحله‌ای (Hybrid Search)', en: '3. Multi-Hop Hybrid RAG & Vector Indexing' },
        durationSeconds: 1920, // 32 min
        videoUrl: VIDEO_STREAM_3,
        summary: {
          fa: 'ترکیب جستجوی متنی BM25 با امبدینگ‌های چگال، ریکرنسر Cohere و قطعه‌بندی معنایی (Semantic Chunking).',
          en: 'Dense vector retrieval combined with lexical BM25, semantic document slicing, and Cohere cross-encoder reranking.'
        },
        keyPoints: [
          { fa: 'پیاده‌سازی جستجوی هیبرید در PostgreSQL با افزونه PgVector', en: 'Hybrid retrieval architecture on PostgreSQL with pgvector' },
          { fa: 'فیلترینگ متادیتا و ارزیابی کیفیت با فریم‌ورک RAGAS', en: 'Metadata filtering and precision evaluation using Ragas' }
        ],
        resources: [
          { id: 'res-4', title: { fa: 'کدهای مرجع پایپ‌لاین RAG', en: 'Production RAG Pipeline Reference' }, fileType: 'zip', fileSize: '8.4 MB' }
        ]
      },
      {
        id: 'chap-llm-4',
        title: { fa: '۴. معماری عامل‌های خودکار با فریم‌ورک LangGraph', en: '4. Autonomous Agent Architecture with LangGraph' },
        durationSeconds: 2100, // 35 min
        videoUrl: VIDEO_STREAM_1,
        summary: {
          fa: 'ساخت ماشین‌های وضعیت چرخه‌ای (Cyclic State Machines)، مدیریت تاریخچه پیام‌ها و هندلینگ خطای عامل در محیط عملیاتی.',
          en: 'Designing cyclic graphs, resilient node transitions, persistent memory checkpoints, and error recovery loops.'
        },
        keyPoints: [
          { fa: 'تعریف گره‌ها و لبه‌های شرطی در LangGraph', en: 'Defining state schemas and conditional edges' },
          { fa: 'تأیید تعاملی توسط انسان در چرخه (Human-in-the-Loop)', en: 'Interactive Human-in-the-Loop approval gates' }
        ],
        resources: [
          { id: 'res-5', title: { fa: 'پروژه استارتر عامل هوشمند LangGraph', en: 'LangGraph Autonomous Agent Starter Pack' }, fileType: 'zip', fileSize: '3.1 MB' }
        ]
      },
      {
        id: 'chap-llm-5',
        title: { fa: '۵. ابزارمحوری و تعامل با APIهای خارجی (Tool & Function Calling)', en: '5. Production Tool Calling & External APIs' },
        durationSeconds: 1800, // 30 min
        videoUrl: VIDEO_STREAM_2,
        summary: {
          fa: 'اتصال مدل به دیتابیس‌های سازمانی، پایگاه‌های خارجی، ابزارهای وب و مدیریت ایمن اعتبارنامه‌ها.',
          en: 'Connecting LLMs to corporate SQL stores, web search grounding, sandbox execution, and credential isolation.'
        },
        keyPoints: [
          { fa: 'مدیریت خطاهای تایم‌اوت و فرمت نادرست آرگومان‌ها', en: 'Handling schema mismatch and execution timeouts' },
          { fa: 'امنیت در برابر تزریق دستورات در پرامپت (Prompt Injection)', en: 'Hardening tool endpoints against prompt injection' }
        ],
        resources: [
          { id: 'res-6', title: { fa: 'راهنمای امنیتی APIهای هوش مصنوعی', en: 'AI Gateway Security Guidelines' }, fileType: 'pdf', fileSize: '2.4 MB' }
        ]
      },
      {
        id: 'chap-llm-6',
        title: { fa: '۶. استقرار، بنچ‌مارک و نظارت در لایه عملیات (LLMOps & Monitoring)', en: '6. LLMOps, Benchmarking & Production Observability' },
        durationSeconds: 2340, // 39 min
        videoUrl: VIDEO_STREAM_3,
        summary: {
          fa: 'ردیابی توکن‌ها با OpenTelemetry، ارزیابی کمی با بنچ‌مارک‌های سفارشی، استقرار vLLM روی سرورهای GPU.',
          en: 'Token tracing via OpenTelemetry, custom evaluation rubrics, continuous evaluation, and vLLM server deployment.'
        },
        keyPoints: [
          { fa: 'کانفیگ سرور vLLM با معماری PagedAttention', en: 'Configuring high-throughput vLLM clusters' },
          { fa: 'داشبورد مانیتورینگ هزینه و نرخ موفقیت درخواست‌ها', en: 'Live Grafana dashboards for latency and cost tracking' }
        ],
        resources: [
          { id: 'res-7', title: { fa: 'فایل داکر کامپوز vLLM و کدهای استقرار', en: 'vLLM Docker Compose & Helm Charts' }, fileType: 'zip', fileSize: '1.9 MB' }
        ]
      }
    ]
  },
  {
    id: 'course-vision-diffusion',
    slug: 'generative-vision-diffusion-models',
    title: {
      fa: 'معماری مدل‌های بینایی ماشین و دیفیوژن مولد (Diffusion & Multimodal AI)',
      en: 'Generative Vision & Latent Diffusion Architectures'
    },
    subtitle: {
      fa: 'دوره جامع ۳ ساعته: مدل‌های انتشار نویز، Stable Diffusion، انکودرهای CLIP و مدل‌های چندوجهی',
      en: 'Complete 3-hour masterclass on DDPM, Latent Diffusion, CLIP alignments, and Multimodal Vision-Language Models'
    },
    description: {
      fa: 'تسلط عمیق بر ریاضیات و مهندسی فرآیند نویززدایی دیفیوژن، آموزش Fine-Tuning با روش LoRA و ControlNet، و پیاده‌سازی پایپ‌لاین‌های پردازش بلادرنگ تصویر و ویدیو در سیستم‌های صنعتی.',
      en: 'Achieve total engineering mastery over Latent Diffusion models, cross-attention conditioning, ControlNet spatial adapters, LoRA weight fine-tuning, and ultra-fast inference pipelines for high-resolution graphics and video.'
    },
    category: 'vision',
    level: 'advanced',
    thumbnail: '/src/assets/images/ai_course_vision_diffusion_1792412070896.jpg',
    previewVideoUrl: VIDEO_STREAM_1,
    instructor: {
      id: 'inst-2',
      name: { fa: 'مهندس سارا نیک‌پی', en: 'Eng. Sara Nikpey' },
      title: { fa: 'متخصص پردازش تصویر و یادگیری بصری مولد', en: 'Staff Computer Vision & Generative AI Scientist' },
      bio: {
        fa: 'پژوهشگر حوزه گرافیک رایانه‌ای و بینایی ماشین با مقالات منتشر شده در کنفرانس‌های CVPR و ICCV.',
        en: 'Computer graphics and computer vision researcher with published works at CVPR and ICCV.'
      },
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
      experienceYears: 9
    },
    totalDurationSeconds: 10800, // Exactly 3 hours
    priceIRR: 2600000,
    originalPriceIRR: 3800000,
    priceUSD: 45,
    originalPriceUSD: 75,
    rating: 4.89,
    reviewsCount: 215,
    updatedAt: '2026-08-20',
    enrolledUserIds: [],
    learningOutcomes: [
      { fa: 'فهم عمیق فرمولاسیون ریاضی نویززدایی معکوس DDPM و DDIM', en: 'Mathematical formulation of forward and reverse denoising dynamics' },
      { fa: 'آموزش و اعمال آداپتورهای ControlNet برای کنترل دقیق ترکیب‌بندی تصویر', en: 'Training and deploying ControlNet adapters for spatial guidance' },
      { fa: 'فاین‌تیونینگ کارآمد مدل‌های پایه‌ای با تکنیک‌های LoRA و Kohya', en: 'Parameter-efficient fine-tuning via LoRA and Textual Inversion' },
      { fa: 'یکپارچه‌سازی مدل‌های چندوجهی Vision-Language در وب‌اپلیکیشن‌ها', en: 'Integrating multimodal VLM visual question answering pipelines' }
    ],
    prerequisites: [
      { fa: 'آشنایی با تنسورها در PyTorch و جبر خطی', en: 'Solid grasp of PyTorch tensors and linear algebra' },
      { fa: 'آشنایی مقدماتی با شبکه‌های عصبی کانولوشنی (CNN)', en: 'Introductory convolutional neural network knowledge' }
    ],
    chapters: [
      {
        id: 'chap-vis-1',
        title: { fa: '۱. مبانی نظری مدل‌های احتمالاتی دیفیوژن (DDPM Theory)', en: '1. Denoising Diffusion Probabilistic Models Theory' },
        durationSeconds: 1800,
        videoUrl: VIDEO_STREAM_2,
        summary: {
          fa: 'تئوری زنجیره‌های مارکوف، افزودن تدریجی نویز گاوسی و استخراج گرادیان احتمالاتی برای معکوس‌سازی نویز.',
          en: 'Markovian diffusion transitions, Gaussian noise scheduling, and mathematical derivation of the variational lower bound.'
        },
        keyPoints: [
          { fa: 'استخراج معادله ریاضی نویززدایی مرحله‌ای', en: 'Step-by-step reverse diffusion formulation' },
          { fa: 'بررسی اسکجولرهای واریانس خطی و کسینوسی', en: 'Linear vs cosine noise scheduling strategies' }
        ],
        resources: [
          { id: 'res-v1', title: { fa: 'چک‌لیست ریاضی فرمول‌های دیفیوژن', en: 'Diffusion Mathematics Companion PDF' }, fileType: 'pdf', fileSize: '3.6 MB' }
        ]
      },
      {
        id: 'chap-vis-2',
        title: { fa: '۲. فضای پنهان و معماری Latent Diffusion (Stable Diffusion)', en: '2. Latent Diffusion Mechanics & VAE Encoders' },
        durationSeconds: 1980,
        videoUrl: VIDEO_STREAM_3,
        summary: {
          fa: 'چرا دیفیوژن در فضای پیکسل کند است؟ نقش Autoencoderهای تنظیمی (KL-VAE) و معماری U-Net با Attention لایه‌ای.',
          en: 'Overcoming pixel-space compute bottlenecks with variational autoencoders, latent representations, and U-Net blocks.'
        },
        keyPoints: [
          { fa: 'توالی فشرده‌سازی در لایه‌های پنهان VAE', en: 'Spatial latent compression ratio tradeoffs' },
          { fa: 'سازوکار Cross-Attention میان پرامپت متنی و ویژگی‌های بصری', en: 'Cross-attention text conditioning mechanics' }
        ],
        resources: [
          { id: 'res-v2', title: { fa: 'کدهای سفارشی استخراج فضای پنهان', en: 'VAE Latent Extraction Script' }, fileType: 'ipynb', fileSize: '2.1 MB' }
        ]
      },
      {
        id: 'chap-vis-3',
        title: { fa: '۳. شرطی‌سازی فضایی پیشرفته با ControlNet و IP-Adapter', en: '3. Spatial Guidance with ControlNet & IP-Adapters' },
        durationSeconds: 2220,
        videoUrl: VIDEO_STREAM_1,
        summary: {
          fa: 'کنترل دقیق پرسپکتیو، لبه‌های Canny، نقشه عمق Depth و ساختار انسانی OpenPose در خروجی تصویر.',
          en: 'Injecting structural geometry via edge detection, depth estimation, human pose estimation, and style reference adapters.'
        },
        keyPoints: [
          { fa: 'وزن‌دهی به لایه‌های منجمد شده و کپی‌های فعال در ControlNet', en: 'Zero-convolution weight initialization' },
          { fa: 'ترکیب چند مدل کنترل‌کننده به‌صورت همزمان', en: 'Multi-control composition strategies' }
        ],
        resources: [
          { id: 'res-v3', title: { fa: 'پروژه استارتر کنترل ساختاری تصویر', en: 'ControlNet Python Pipeline Assets' }, fileType: 'zip', fileSize: '14.2 MB' }
        ]
      },
      {
        id: 'chap-vis-4',
        title: { fa: '۴. تکنیک‌های فاین‌تیونینگ LoRA و سفارشی‌سازی سبک', en: '4. LoRA Training & Style Personalization' },
        durationSeconds: 1680,
        videoUrl: VIDEO_STREAM_2,
        summary: {
          fa: 'آموزش ماتریس‌های رنک پایین (Low-Rank Adaptation) با حداقل مصرف VRAM برای چهره‌ها و برندینگ شرکتی.',
          en: 'Low-rank matrix decomposition for efficient parameter updates on modest GPU hardware without catastrophic forgetting.'
        },
        keyPoints: [
          { fa: 'تنظیم نرخ یادگیری Text Encoder و UNet در LoRA', en: 'Balancing learning rates across text encoder and UNet' },
          { fa: 'جلوگیری از Overfitting با تصاویر منظم‌ساز (Regularization)', en: 'Regularization image strategies' }
        ],
        resources: [
          { id: 'res-v4', title: { fa: 'اسکریپت آموزش LoRA با شتاب‌دهنده Kohya', en: 'Kohya LoRA Training Configuration' }, fileType: 'json', fileSize: '120 KB' }
        ]
      },
      {
        id: 'chap-vis-5',
        title: { fa: '۵. مدل‌های بینایی-زبانی (VLMs) و درک معنایی تصویر', en: '5. Vision-Language Models & Scene Understanding' },
        durationSeconds: 1620,
        videoUrl: VIDEO_STREAM_3,
        summary: {
          fa: 'استفاده از مدل‌های چندوجهی مدرن (مانند LLaVA و Gemini Vision) برای استخراج متادیتا، OCR پیشرفته و پاسخ به سؤالات بصری.',
          en: 'Multimodal vision encoders, projection tokens, dense captioning, and zero-shot reasoning on visual documents.'
        },
        keyPoints: [
          { fa: 'پروژکشن خطی فیچرهای بصری به توکن‌های زبانی', en: 'Linear projection layer mechanics' },
          { fa: 'پایپ‌لاین بازرسی کیفیت تصاویر با VLM', en: 'Automated QA screening with vision models' }
        ],
        resources: [
          { id: 'res-v5', title: { fa: 'کدهای تست و استنتاج VLM', en: 'VLM Inference Starter Notebook' }, fileType: 'ipynb', fileSize: '1.8 MB' }
        ]
      },
      {
        id: 'chap-vis-6',
        title: { fa: '۶. بهینه‌سازی سرعت استنتاج با TensorRT و SDXL Turbo', en: '6. Ultra-Fast Inference with TensorRT & Distillation' },
        durationSeconds: 1500,
        videoUrl: VIDEO_STREAM_1,
        summary: {
          fa: 'کاهش زمان تولید تصویر به زیر ۱۰۰ میلی‌ثانیه با کامپایل TensorRT، تقطیر یک‌مرحله‌ای (1-step distillation) و بهینه‌سازی حافظه.',
          en: 'Compiling UNet engines with NVIDIA TensorRT, single-step latent distillation, and GPU memory management.'
        },
        keyPoints: [
          { fa: 'کامپایل انجین‌های TensorRT برای مدل‌های پایه‌ای', en: 'Building TensorRT plan files' },
          { fa: 'سرویس‌دهی وب با استریم مستقیم وب‌سوکت', en: 'Real-time WebSocket streaming architectures' }
        ],
        resources: [
          { id: 'res-v6', title: { fa: 'پیکربندی استقرار سریع TensorRT', en: 'TensorRT Docker Deployment Recipe' }, fileType: 'zip', fileSize: '3.5 MB' }
        ]
      }
    ]
  },
  {
    id: 'course-systems-infra',
    slug: 'distributed-ai-infrastructure-vector-systems',
    title: {
      fa: 'زیرساخت توزیع‌شده و مهندسی سیستم‌های هوش مصنوعی (Fullstack AI Systems)',
      en: 'Enterprise AI Infrastructure, Vector Databases & ML Systems'
    },
    subtitle: {
      fa: 'دوره جامع ۳ ساعته: معماری مقیاس‌پذیر کلاسترهای GPU، پایگاه‌های داده برداری، کشینگ معنایی و پایپ‌لاین‌های بلادرنگ',
      en: 'Intensive 3-hour masterclass on GPU cluster orchestration, HNSW vector indexing, semantic caching, and low-latency inference'
    },
    description: {
      fa: 'طراحی زیرساخت‌های پایدار برای سیستم‌های هوش مصنوعی که روزانه میلیون‌ها درخواست را با کمترین تأخیر و بالاترین امنیت پردازش می‌کنند. شامل مانیتورینگ دقیق، خوشه‌بندی توزیع‌شده و سیستم‌های کشینگ معنایی.',
      en: 'Architect resilient, production-hardened infrastructure capable of serving millions of inference calls with sub-50ms latency, enterprise rate limiting, semantic caching layers, and high-throughput vector indexes.'
    },
    category: 'systems',
    level: 'advanced',
    thumbnail: '/src/assets/images/ai_course_fullstack_systems_1792412071586.jpg',
    previewVideoUrl: VIDEO_STREAM_3,
    instructor: {
      id: 'inst-3',
      name: { fa: 'مهندس نیما دادفر', en: 'Eng. Nima Dadfar' },
      title: { fa: 'معمار ارشد زیرساخت ابری و سیستم‌های توزیع‌شده', en: 'Principal Cloud Systems & MLOps Architect' },
      bio: {
        fa: 'طراح سیستم‌های مقیاس بالا با سابقه هدایت زیرساخت‌های کلان‌داده و پایگاه‌های برداری توزیع‌شده در شرکت‌های بین‌المللی.',
        en: 'Over 14 years building planetary-scale data systems, distributed GPU schedulers, and fault-tolerant streaming brokers.'
      },
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
      experienceYears: 14
    },
    totalDurationSeconds: 11100, // 3 hours 5 mins
    priceIRR: 3100000,
    originalPriceIRR: 4500000,
    priceUSD: 54,
    originalPriceUSD: 85,
    rating: 4.96,
    reviewsCount: 184,
    updatedAt: '2026-09-01',
    enrolledUserIds: [],
    learningOutcomes: [
      { fa: 'پیکربندی کلاسترهای کوبرنتیز برای مدیریت و توزیع بارهای کاری GPU', en: 'Orchestrating Kubernetes clusters with NVIDIA GPU operator plugins' },
      { fa: 'پیاده‌سازی ایندکس‌های الگوریتم HNSW و IVFFlat در پایگاه‌های برداری مقیاس‌پذیر', en: 'Tuning HNSW and IVFFlat vector index parameters for recall vs speed' },
      { fa: 'معماری کش معنایی بر پایه Redis برای کاهش ۹۰٪ هزینه‌های API', en: 'Designing semantic caching architectures on Redis for massive cost savings' },
      { fa: 'تنظیم Gateway امنیتی با کنترل Rate Limit و سهمیه‌بندی سازمانی', en: 'Deploying high-throughput AI API gateways with dynamic rate limiting' }
    ],
    prerequisites: [
      { fa: 'تجربه کار با لینوکس، داکر و معماری‌های مایکروسرویس', en: 'Solid Docker, Linux terminal, and microservices experience' },
      { fa: 'آشنایی با مفاهیم پایگاه داده و شبکه‌های رایانه‌ای', en: 'Database fundamentals and distributed systems basics' }
    ],
    chapters: [
      {
        id: 'chap-sys-1',
        title: { fa: '۱. کالبدشکافی خوشه‌های GPU و معماری حافظه vRAM', en: '1. GPU Cluster Topologies & vRAM Memory Hierarchy' },
        durationSeconds: 1740,
        videoUrl: VIDEO_STREAM_1,
        summary: {
          fa: 'بررسی ارتباطات NVLink، پهنای باند PCIe Gen 5، حافظه HBM3 و تقسیم حافظه با روش‌های کوانتایزاسیون (AWQ, GPTQ).',
          en: 'Hardware interconnects, NVLink topology, memory bandwidth constraints, and precision quantization strategies.'
        },
        keyPoints: [
          { fa: 'محاسبه دقیق حافظه مورد نیاز برای پارامترها و KV-Cache', en: 'Exact KV-cache and model weight vRAM sizing formulas' },
          { fa: 'تفاوت کوانتایزاسیون ۴ بیتی AWQ در مقابل FP8', en: 'FP8 vs 4-bit AWQ latency and precision trade-offs' }
        ],
        resources: [
          { id: 'res-s1', title: { fa: 'ماشین‌حساب محاسبه vRAM هوش مصنوعی', en: 'vRAM Sizing Calculator Sheet' }, fileType: 'json', fileSize: '150 KB' }
        ]
      },
      {
        id: 'chap-sys-2',
        title: { fa: '۲. پایگاه‌های داده برداری در مقیاس میلیون آیتم (HNSW Deep Dive)', en: '2. Planetary Scale Vector Databases & HNSW Indexing' },
        durationSeconds: 1980,
        videoUrl: VIDEO_STREAM_2,
        summary: {
          fa: 'گراف‌های HNSW، تنظیم پارامترهای efConstruction و M، مقایسه کارایی Qdrant, Milvus و pgvector در بارهای سنگین.',
          en: 'Hierarchical Navigable Small World graphs, hyperparameter optimization, and benchmarks across Qdrant and pgvector.'
        },
        keyPoints: [
          { fa: 'تعادل بین دقت یادآوری (Recall) و سرعت جستجو (QPS)', en: 'Fine-tuning recall vs query per second latency' },
          { fa: 'کاهش حجم ایندکس با تکنیک Scalar Quantization', en: 'Scalar and product vector quantization in production' }
        ],
        resources: [
          { id: 'res-s2', title: { fa: 'اسکریپت بنچ‌مارک پایگاه‌های داده برداری', en: 'Vector Store Benchmark Scripts' }, fileType: 'zip', fileSize: '4.2 MB' }
        ]
      },
      {
        id: 'chap-sys-3',
        title: { fa: '۳. کش معنایی (Semantic Caching) و بهینه‌سازی توکن', en: '3. Semantic Caching & Token Reduction Architectures' },
        durationSeconds: 1860,
        videoUrl: VIDEO_STREAM_3,
        summary: {
          fa: 'استفاده از فاصله کسینوسی برای شناسایی پرسش‌های مشابه کاربران و بازگرداندن پاسخ‌های کش‌شده بدون فراخوانی مجدد مدل.',
          en: 'Similarity threshold tuning on Redis, semantic fingerprinting, and invalidation strategies for live data.'
        },
        keyPoints: [
          { fa: 'ساخت کش لایه ۲ با سازگاری استریم پاسخ', en: 'L2 semantic cache with stream preservation' },
          { fa: 'پایش نرخ اصابت کش (Hit Rate) و کاهش هزینه‌ها', en: 'Real-time cache hit metrics and cost audit' }
        ],
        resources: [
          { id: 'res-s3', title: { fa: 'کدهای راه‌اندازی کش با Redis و فست‌ای‌پی‌آی', en: 'FastAPI + Redis Semantic Cache Repo' }, fileType: 'zip', fileSize: '2.5 MB' }
        ]
      },
      {
        id: 'chap-sys-4',
        title: { fa: '۴. راه‌اندازی سرور استنتاج vLLM و ترایتون (Triton Server)', en: '4. High-Throughput Model Serving with vLLM & Triton' },
        durationSeconds: 2160,
        videoUrl: VIDEO_STREAM_1,
        summary: {
          fa: 'تکنیک Continuous Batching، مدیریت پویای صف درخواست‌ها و تخصیص بهینه منابع با سرورهای صنعتی vLLM.',
          en: 'Continuous batching dynamics, prefill vs decode phase scheduling, and multi-model Triton pipelines.'
        },
        keyPoints: [
          { fa: 'افزایش ۴ برابری Throughput با Continuous Batching', en: '4x throughput multiplier via dynamic batching' },
          { fa: 'تنظیم ماکسیمم طول توکن در ثانیه برای هر کارت گرافیک', en: 'Tokens per second rate governance' }
        ],
        resources: [
          { id: 'res-s4', title: { fa: 'فایل پیکربندی عملیاتی سرور vLLM', en: 'Production vLLM Cluster Config' }, fileType: 'zip', fileSize: '3.1 MB' }
        ]
      },
      {
        id: 'chap-sys-5',
        title: { fa: '۵. امنیت سیستم‌های AI و دفاع در برابر حملات تزریق پرامپت', en: '5. AI Security, Guardrails & Jailbreak Prevention' },
        durationSeconds: 1680,
        videoUrl: VIDEO_STREAM_2,
        summary: {
          fa: 'پیاده‌سازی گیت‌وی‌های امنیتی (Guardrails)، مهار نشت داده‌های حساس (PII Masking) و جلوگیری از فرامین مخرب.',
          en: 'Implementing input/output guardrail layers, PII anonymization, prompt firewalling, and audit log pipelines.'
        },
        keyPoints: [
          { fa: 'استفاده از مدل‌های سبک طبقه‌بندی برای مسدودسازی حملات', en: 'Low-latency classifier models for firewalling' },
          { fa: 'ماسک‌سازی اتوماتیک داده‌های هویتی قبل از ارسال به مدل', en: 'Automatic PII scrubbing before third-party calls' }
        ],
        resources: [
          { id: 'res-s5', title: { fa: 'قالب‌های قوانین امنیتی NeMo Guardrails', en: 'NeMo Guardrails Rule Templates' }, fileType: 'json', fileSize: '450 KB' }
        ]
      },
      {
        id: 'chap-sys-6',
        title: { fa: '۶. مانیتورینگ بلادرنگ، متریک‌های سیستم و پایپ‌لاین‌های لاگ', en: '6. Production Observability, Latency & Audit Logging' },
        durationSeconds: 1680,
        videoUrl: VIDEO_STREAM_3,
        summary: {
          fa: 'یکپارچه‌سازی لاگ‌های تریس با OpenTelemetry، دشبوردهای Grafana و اعلام خودکار هشدارهای افت کیفیت مدل.',
          en: 'OpenTelemetry span tracing, Grafana alerts for latency spikes, and automated drift detection alerts.'
        },
        keyPoints: [
          { fa: 'ثبت متادیتا بدون نشت داده‌های حریم خصوصی کاربران', en: 'Zero-PII span tracing instrumentation' },
          { fa: 'سیستم هشداردهی هوشمند بر اساس SLA پاسخ‌دهی', en: 'SLA breach alerts over webhook integrations' }
        ],
        resources: [
          { id: 'res-s6', title: { fa: 'دشبوردهای آماده گرانافا برای هوش مصنوعی', en: 'Grafana AI Observability Dashboards' }, fileType: 'json', fileSize: '850 KB' }
        ]
      }
    ]
  },
  {
    id: 'bundle-ai-mastery',
    slug: 'executive-ai-engineering-mastery-bundle',
    title: {
      fa: 'پکیج جامع دیجیتال: متخصص جامع مهندسی هوش مصنوعی (Mastery Pack)',
      en: 'Executive AI Engineering Digital Bundle (All-in-One)'
    },
    subtitle: {
      fa: 'پکیج طلایی شامل هر سه مسترکلاس جامع (بیش از ۹ ساعت آموزش فشرده) به همراه کدهای سورس کامل و مدرک رسمی',
      en: 'Complete digital bundle including all three 3-hour masterclasses (9+ hours total), verified project repos, and priority certificates'
    },
    description: {
      fa: 'جامع‌ترین مسیر یادگیری مهندسی هوش مصنوعی. با خرید این پکیج یکباره، به هر سه دوره تخصصی (مدل‌های زبانی، بینایی مولد، و زیرساخت‌های توزیع‌شده) با تخفیف ویژه دسترسی مادام‌العمر پیدا خواهید کرد.',
      en: 'The definitive end-to-end curriculum for elite AI engineers. One-time purchase granting perpetual access to all 3 masterclasses with verified certificates and full source code repositories.'
    },
    category: 'bundle',
    level: 'all-levels',
    thumbnail: '/src/assets/images/ai_bundle_mastery_pack_1792412071069.jpg',
    previewVideoUrl: VIDEO_STREAM_1,
    instructor: {
      id: 'inst-all',
      name: { fa: 'شورای مدرسین ارشد آکادمی هوش مصنوعی', en: 'AI School Faculty Board' },
      title: { fa: 'مجموعه اساتید و معماران ارشد سیستم‌های هوش مصنوعی', en: 'Senior AI Research & Engineering Faculty' },
      bio: {
        fa: 'منتخبی از برترین متخصصان و پژوهشگران یادگیری عمیق، زیرساخت و پردازش زبان طبیعی.',
        en: 'A collaborative board of world-class AI engineers and senior research leads.'
      },
      avatar: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=200&q=80',
      experienceYears: 15
    },
    totalDurationSeconds: 33300, // 9.25 hours total!
    priceIRR: 5900000, // 5,900,000 Tomans (big bundle discount)
    originalPriceIRR: 8550000,
    priceUSD: 99,
    originalPriceUSD: 148,
    rating: 4.98,
    reviewsCount: 512,
    updatedAt: '2026-09-20',
    isBundle: true,
    includedCourseIds: ['course-llm-agents', 'course-vision-diffusion', 'course-systems-infra'],
    enrolledUserIds: [],
    learningOutcomes: [
      { fa: 'تسلط کامل ۳۶۰ درجه بر هوش مصنوعی مولد: متن، تصویر، عامل‌ها و سیستم‌های توزیع‌شده', en: 'Complete 360-degree generative AI mastery: text, vision, agents, and systems' },
      { fa: 'بیش از ۲۰ پروژه و نوت‌بوک آماده استقرار تجاری در شرکت‌ها و استارتاپ‌ها', en: 'Over 20 production-ready notebooks and enterprise blueprints' },
      { fa: 'دریافت مدرک تخصصی طلایی آکادمی AI School با امکان استعلام اصالت دیجیتال', en: 'Verified digital certificate with cryptographic credential verification' },
      { fa: 'تخفیف ویژه ۴۰ درصدی نسبت به خرید مجزای هر دوره', en: 'Significant bundled savings compared to individual module purchases' }
    ],
    prerequisites: [
      { fa: 'علاقه‌مندی جدی به توسعه نرم‌افزار و هوش مصنوعی مدرن', en: 'Strong interest in cutting-edge software and applied AI engineering' }
    ],
    chapters: [
      {
        id: 'chap-bnd-1',
        title: { fa: 'معرفی جامع پکیج طلایی و نقشه راه تخصصی هوش مصنوعی', en: 'Executive Bundle Introduction & Career Roadmap' },
        durationSeconds: 1200,
        videoUrl: VIDEO_STREAM_4,
        summary: {
          fa: 'بررسی نقشه راه جامع، چگونگی پیوند مهندسی مدل‌های زبانی با بینایی ماشین و استقرار زیرساختی.',
          en: 'Curriculum map overview, bridging LLMs with vision perception and production cloud deployment.'
        },
        keyPoints: [
          { fa: 'استراتژی مطالعه و تقدم یادگیری ماژول‌ها', en: 'Optimal module sequence and project timeline' },
          { fa: 'آماده‌سازی محیط کاری توسعه بر بستر ابری', en: 'Cloud GPU workspace setup guidelines' }
        ],
        resources: [
          { id: 'res-b1', title: { fa: 'دفترچه راهنمای جامع مهندسی هوش مصنوعی (PDF)', en: 'AI Engineering Master Roadmap (PDF)' }, fileType: 'pdf', fileSize: '12.8 MB' }
        ]
      }
    ]
  }
];

export const INITIAL_USER: User = {
  id: 'user-farzad',
  name: 'فرزاد مهجور',
  email: 'farzadmahjor1386@gmail.com',
  role: 'learner',
  avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80',
  enrolledCourseIds: ['course-llm-agents'],
  watchProgress: {
    'course-llm-agents': {
      lastChapterId: 'chap-llm-1',
      lastPositionSeconds: 420, // 7 minutes in
      completedChapterIds: [],
      lastWatchedAt: '2026-10-18T18:30:00Z',
      certificateIssued: false
    }
  }
};

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-9042',
    userId: 'user-farzad',
    userEmail: 'farzadmahjor1386@gmail.com',
    userName: 'فرزاد مهجور',
    userPhone: '+989123456789',
    items: [
      {
        courseId: 'course-llm-agents',
        title: {
          fa: 'مستربکلاس مدل‌های زبانی بزرگ و سیستم‌های عامل‌محور (LLMs & Multi-Agent Systems)',
          en: 'Mastering LLMs & Autonomous Multi-Agent Architectures'
        },
        priceIRR: 2850000,
        priceUSD: 49
      }
    ],
    currency: 'IRR',
    subtotal: 2850000,
    discount: 0,
    tax: 0,
    total: 2850000,
    gateway: 'zarinpal',
    status: 'completed',
    createdAt: '2026-10-18T18:25:14Z',
    transactionRef: 'ZRN-83921094',
    trackingCode: 'TRK-IR-749102',
    cardMask: '۶۰۳۷-۹۹**-****-۵۴۱۲',
    billingCountry: 'Iran'
  },
  {
    id: 'ord-8831',
    userId: 'user-sample-2',
    userEmail: 'michael.k@techcorp.io',
    userName: 'Michael Keller',
    items: [
      {
        courseId: 'bundle-ai-mastery',
        title: {
          fa: 'پکیج جامع دیجیتال: متخصص جامع مهندسی هوش مصنوعی (Mastery Pack)',
          en: 'Executive AI Engineering Digital Bundle (All-in-One)'
        },
        priceIRR: 5900000,
        priceUSD: 99
      }
    ],
    currency: 'USD',
    subtotal: 99,
    discount: 10,
    couponCode: 'WELCOME10',
    tax: 4.95,
    total: 93.95,
    gateway: 'stripe',
    status: 'completed',
    createdAt: '2026-10-17T11:14:02Z',
    transactionRef: 'pi_3MtwadLkdIwHu7ix28a30q2c',
    trackingCode: 'STR-US-992314',
    cardMask: '4242-****-****-4242',
    billingCountry: 'United States'
  }
];
